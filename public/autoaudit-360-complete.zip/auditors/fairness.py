"""
Auditors: Fairness & Algorithmic Bias Assessment
Implements EEOC 80% Rule (Disparate Impact), Demographic Parity, Equal Opportunity, and Equalized Odds.
"""

from typing import Dict, Any, List, Optional
import numpy as np
import pandas as pd
from config import THRESHOLDS

def bin_continuous_attribute(series: pd.Series, n_bins: int = 3) -> pd.Series:
    """Bin continuous numerical attributes (like age) into human-readable discrete cohorts."""
    if not pd.api.types.is_numeric_dtype(series):
        return series.astype(str)
    
    unique_vals = series.nunique()
    if unique_vals <= 4:
        return series.astype(str)
        
    # Domain-specific heuristic for age
    name = str(series.name).lower()
    if "age" in name:
        bins = [-np.inf, 25, 60, np.inf]
        labels = ["Young (<25)", "Prime (25-60)", "Senior (>60)"]
        return pd.cut(series, bins=bins, labels=labels, right=False).astype(str)
    
    # Generic quantile binning
    try:
        return pd.qcut(series, q=n_bins, labels=[f"Tier {i+1}" for i in range(n_bins)], duplicates="drop").astype(str)
    except Exception:
        return pd.cut(series, bins=n_bins, labels=[f"Range {i+1}" for i in range(n_bins)]).astype(str)

def audit_fairness(
    df: pd.DataFrame,
    target_col: str,
    y_pred: np.ndarray,
    sensitive_cols: List[str],
    positive_label: Any = 1,
    privileged_groups: Optional[Dict[str, str]] = None
) -> List[Dict[str, Any]]:
    """
    Evaluate fairness metrics for each sensitive attribute.
    
    Returns structured audit list with:
    - selection_rate_per_group
    - disparate_impact_ratio
    - demographic_parity_diff
    - equal_opportunity_diff
    - equalized_odds_gap
    - per_group_rates (FPR, FNR, TPR, TNR, counts)
    - small_group_warnings
    - status ('pass', 'warn', 'fail')
    - plain-English finding
    - chart_data
    """
    privileged_groups = privileged_groups or {}
    results = []
    
    y_true = (df[target_col].values == positive_label).astype(int)
    y_hat = (np.array(y_pred) == positive_label).astype(int)
    
    for col in sensitive_cols:
        if col not in df.columns:
            continue
            
        raw_series = df[col]
        # Bin if continuous
        series = bin_continuous_attribute(raw_series)
        unique_groups = sorted([str(g) for g in series.unique() if pd.notna(g)])
        
        if len(unique_groups) < 2:
            results.append({
                "attribute": col,
                "status": "warn",
                "severity": "low",
                "message": f"Attribute '{col}' has fewer than 2 distinct subgroups.",
                "metrics": {},
                "groups": unique_groups
            })
            continue

        # Compute group statistics
        group_stats = {}
        selection_rates = {}
        small_groups = []
        
        for g in unique_groups:
            mask = (series == g).values
            n_g = int(np.sum(mask))
            if n_g < THRESHOLDS["min_subgroup_sample_size"]:
                small_groups.append({"group": g, "size": n_g})
                
            if n_g == 0:
                continue
                
            y_true_g = y_true[mask]
            y_hat_g = y_hat[mask]
            
            sel_rate = float(np.mean(y_hat_g))
            selection_rates[g] = sel_rate
            
            # Confusion matrix elements for group
            tp = int(np.sum((y_hat_g == 1) & (y_true_g == 1)))
            fp = int(np.sum((y_hat_g == 1) & (y_true_g == 0)))
            fn = int(np.sum((y_hat_g == 0) & (y_true_g == 1)))
            tn = int(np.sum((y_hat_g == 0) & (y_true_g == 0)))
            
            pos_count = tp + fn
            neg_count = fp + tn
            
            tpr = float(tp / pos_count) if pos_count > 0 else 0.0
            fpr = float(fp / neg_count) if neg_count > 0 else 0.0
            fnr = float(fn / pos_count) if pos_count > 0 else 0.0
            tnr = float(tn / neg_count) if neg_count > 0 else 0.0
            
            group_stats[g] = {
                "size": n_g,
                "selection_rate": round(sel_rate, 4),
                "tpr": round(tpr, 4),
                "fpr": round(fpr, 4),
                "fnr": round(fnr, 4),
                "tnr": round(tnr, 4),
                "tp": tp, "fp": fp, "fn": fn, "tn": tn
            }
            
        # Determine Privileged and Unprivileged Groups
        priv_group = privileged_groups.get(col)
        if not priv_group or priv_group not in selection_rates:
            # Auto-assign group with highest base selection rate as privileged baseline
            priv_group = max(selection_rates.items(), key=lambda x: x[1])[0]
            
        priv_sel_rate = selection_rates.get(priv_group, 0.0)
        
        # Calculate worst disparate impact and gaps against the privileged group
        di_ratios = {}
        dp_diffs = {}
        eo_diffs = {}
        fpr_diffs = {}
        
        for g, s_rate in selection_rates.items():
            if g == priv_group:
                continue
            # Disparate Impact ratio: unprivileged / privileged
            if priv_sel_rate > 0:
                di = s_rate / priv_sel_rate
            else:
                di = 1.0 if s_rate == 0 else 0.0
            di_ratios[g] = round(di, 4)
            
            # Demographic Parity Difference
            dp_diffs[g] = round(abs(priv_sel_rate - s_rate), 4)
            
            # Equal Opportunity Difference (TPR gap)
            priv_tpr = group_stats[priv_group]["tpr"]
            eo_diffs[g] = round(abs(priv_tpr - group_stats[g]["tpr"]), 4)
            
            # FPR gap
            priv_fpr = group_stats[priv_group]["fpr"]
            fpr_diffs[g] = round(abs(priv_fpr - group_stats[g]["fpr"]), 4)

        # Worst metrics across cohorts
        worst_di = min(di_ratios.values()) if di_ratios else 1.0
        worst_dpd = max(dp_diffs.values()) if dp_diffs else 0.0
        worst_eod = max(eo_diffs.values()) if eo_diffs else 0.0
        worst_fpr_gap = max(fpr_diffs.values()) if fpr_diffs else 0.0
        equalized_odds_gap = max(worst_eod, worst_fpr_gap)
        
        # Evaluate Pass / Warn / Fail against strict regulatory thresholds
        di_thresh = THRESHOLDS["disparate_impact"]
        gap_thresh = THRESHOLDS["parity_gap"]
        
        reasons = []
        status = "pass"
        severity = "none"
        
        if worst_di < di_thresh["fail"] or worst_dpd > gap_thresh["warn"] or worst_eod > gap_thresh["warn"]:
            status = "fail"
            severity = "high"
            if worst_di < di_thresh["fail"]:
                reasons.append(f"Disparate Impact ({worst_di:.2f}) violates EEOC 80% rule (<{di_thresh['fail']}).")
            if worst_dpd > gap_thresh["warn"]:
                reasons.append(f"Demographic Parity Difference ({worst_dpd:.2%}) exceeds 20% tolerance.")
            if worst_eod > gap_thresh["warn"]:
                reasons.append(f"Equal Opportunity Difference ({worst_eod:.2%}) indicates significant recall disparity.")
        elif worst_di < di_thresh["pass"] or worst_dpd > gap_thresh["pass"] or worst_eod > gap_thresh["pass"]:
            status = "warn"
            severity = "medium"
            if worst_di < di_thresh["pass"]:
                reasons.append(f"Disparate Impact ({worst_di:.2f}) is in warning band [0.70, 0.80).")
            if worst_dpd > gap_thresh["pass"]:
                reasons.append(f"Demographic Parity gap ({worst_dpd:.2%}) exceeds 10% target.")
            if worst_eod > gap_thresh["pass"]:
                reasons.append(f"Equal Opportunity gap ({worst_eod:.2%}) exceeds 10% target.")
        else:
            reasons.append(f"All demographic parity and disparate impact checks passed within 80% rule thresholds.")

        if small_groups:
            reasons.append(f"Statistical sample warning: {len(small_groups)} group(s) have under {THRESHOLDS['min_subgroup_sample_size']} observations.")

        # Chart Data Preparation (Group selection rates vs 80% rule line)
        eighty_pct_line = round(priv_sel_rate * 0.80, 4)
        chart_labels = list(selection_rates.keys())
        chart_values = [round(v * 100, 2) for v in selection_rates.values()]
        
        results.append({
            "attribute": col,
            "privileged_group": priv_group,
            "status": status,
            "severity": severity,
            "finding": " ".join(reasons),
            "metrics": {
                "disparate_impact_ratio": round(worst_di, 4),
                "demographic_parity_difference": round(worst_dpd, 4),
                "equal_opportunity_difference": round(worst_eod, 4),
                "equalized_odds_gap": round(equalized_odds_gap, 4),
                "worst_fpr_gap": round(worst_fpr_gap, 4),
            },
            "subgroup_breakdown": group_stats,
            "di_per_subgroup": di_ratios,
            "small_group_warnings": small_groups,
            "chart_data": {
                "labels": chart_labels,
                "selection_rates_pct": chart_values,
                "eighty_percent_line_pct": round(eighty_pct_line * 100, 2),
                "privileged_rate_pct": round(priv_sel_rate * 100, 2)
            }
        })
        
    return results
