"""
Auditors: AI Model Card Generator
Generates self-contained, printable, and downloadable HTML/JSON AI Model Cards.
"""

import json
import hashlib
from typing import Dict, Any
from jinja2 import Template

MODEL_CARD_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AI Model Card: {{ meta.model_name }} | AutoAudit-360</title>
  <style>
    @page { size: A4; margin: 15mm; }
    * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #1e293b;
      line-height: 1.5;
      font-size: 13px;
      background: #f8fafc;
      margin: 0;
      padding: 24px;
    }
    .container {
      max-width: 900px;
      margin: 0 auto;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 32px;
      box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
    }
    .header-bar {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 2px solid #0f172a;
      padding-bottom: 16px;
      margin-bottom: 24px;
    }
    .title-area h1 {
      margin: 0 0 6px 0;
      font-size: 24px;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: -0.02em;
    }
    .title-area .badge {
      display: inline-block;
      padding: 3px 8px;
      font-size: 11px;
      font-weight: 700;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .badge-green { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
    .badge-amber { background: #fef3c7; color: #92400e; border: 1px solid #fcd34d; }
    .badge-red { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
    .stamp {
      border: 2px dashed #0f172a;
      padding: 8px 14px;
      font-size: 13px;
      font-weight: 800;
      text-align: center;
      border-radius: 6px;
      transform: rotate(-2deg);
    }
    .disclaimer-banner {
      background: #eff6ff;
      border-left: 4px solid #3b82f6;
      padding: 10px 14px;
      margin-bottom: 24px;
      font-size: 12px;
      color: #1e40af;
    }
    .grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 20px;
    }
    .grid-3 {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 12px;
      margin-bottom: 20px;
    }
    .card {
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 14px;
      background: #f8fafc;
    }
    .card h3 {
      margin: 0 0 8px 0;
      font-size: 13px;
      font-weight: 700;
      color: #334155;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .metric-value {
      font-size: 20px;
      font-weight: 800;
      font-family: monospace;
      color: #0f172a;
    }
    .metric-sub {
      font-size: 11px;
      color: #64748b;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 12px 0 20px 0;
      font-size: 12px;
    }
    th, td {
      padding: 8px 10px;
      text-align: left;
      border-bottom: 1px solid #e2e8f0;
    }
    th {
      background: #f1f5f9;
      color: #475569;
      font-weight: 600;
    }
    section {
      margin-bottom: 28px;
    }
    h2 {
      font-size: 16px;
      font-weight: 700;
      color: #0f172a;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 6px;
      margin-top: 24px;
      margin-bottom: 12px;
    }
    .footer {
      border-top: 2px solid #0f172a;
      padding-top: 14px;
      margin-top: 32px;
      font-size: 11px;
      color: #64748b;
      display: flex;
      justify-content: space-between;
    }
    .print-hide {
      margin-bottom: 16px;
      display: flex;
      gap: 10px;
    }
    button {
      background: #0f172a;
      color: #ffffff;
      border: none;
      padding: 8px 16px;
      font-size: 12px;
      font-weight: 600;
      border-radius: 4px;
      cursor: pointer;
    }
    button:hover { background: #334155; }
    @media print {
      body { background: #ffffff; padding: 0; }
      .container { border: none; box-shadow: none; padding: 0; }
      .print-hide { display: none !important; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="print-hide">
      <button onclick="window.print()">Print / Save as PDF</button>
      <button onclick="downloadJson()">Download Full Audit JSON</button>
    </div>

    <div class="header-bar">
      <div class="title-area">
        <h1>AI MODEL CARD: {{ meta.model_name }}</h1>
        <div>
          <span class="badge {% if scores.rag_status == 'green' %}badge-green{% elif scores.rag_status == 'amber' %}badge-amber{% else %}badge-red{% endif %}">
            Status: {{ scores.rag_status | upper }} (Score {{ scores.overall_trust_score }}/100)
          </span>
          <span style="margin-left: 8px; font-size: 12px; color: #64748b;">Audit ID: {{ meta.audit_id }}</span>
        </div>
      </div>
      <div class="stamp">
        {% if scores.rag_status == 'green' %}
          CERTIFIED TRUSTWORTHY
        {% elif scores.rag_status == 'amber' %}
          CONDITIONAL / REVIEW
        {% else %}
          HIGH REGULATORY RISK
        {% endif %}
      </div>
    </div>

    <div class="disclaimer-banner">
      <strong>Statutory Transparency Notice:</strong> This AI Model Card compiles automated empirical audit diagnostics and self-declared governance disclosures. Findings reflect statistical indicators and mathematical bounds; they do <em>not</em> constitute a formal legal compliance certificate or legal indemnity.
    </div>

    <!-- Section 1: Overview & Intended Use -->
    <section>
      <h2>1. Model Details & Scope of Application</h2>
      <div class="grid-2">
        <div class="card">
          <h3>Architecture & Algorithm</h3>
          <div><strong>Model Type:</strong> {{ meta.algorithm }}</div>
          <div><strong>Framework:</strong> {{ meta.framework }}</div>
          <div><strong>Optimization Target:</strong> {{ data_summary.target_column }} (Binary Classification)</div>
          <div><strong>Random State:</strong> {{ meta.random_seed }}</div>
        </div>
        <div class="card">
          <h3>Intended & Out-of-Scope Use</h3>
          <div><strong>Intended Domain:</strong> {{ compliance.use_case.title }}</div>
          <div><strong>EU AI Act Tier:</strong> {{ compliance.eu_ai_act.classification }}</div>
          <div><strong>Prohibited Use:</strong> Fully autonomous adverse action without human supervisor review.</div>
        </div>
      </div>
    </section>

    <!-- Section 2: Data Summary -->
    <section>
      <h2>2. Dataset Summary & Protected Demographics</h2>
      <div class="grid-3">
        <div class="card">
          <h3>Dataset Scale</h3>
          <div class="metric-value">{{ data_summary.total_rows }}</div>
          <div class="metric-sub">{{ data_summary.total_features }} features, {{ data_summary.missing_percentage }}% missing</div>
        </div>
        <div class="card">
          <h3>Class Distribution</h3>
          <div class="metric-value">{{ data_summary.positive_rate }}%</div>
          <div class="metric-sub">Favorable outcome rate (y={{ data_summary.positive_label }})</div>
        </div>
        <div class="card">
          <h3>Dataset SHA-256</h3>
          <div style="font-family: monospace; font-size: 11px; word-break: break-all;">
            {{ meta.dataset_hash[:24] }}...
          </div>
          <div class="metric-sub">Cryptographic verification hash</div>
        </div>
      </div>
    </section>

    <!-- Section 3: Performance -->
    <section>
      <h2>3. Quantitative Model Performance</h2>
      <div class="grid-3">
        <div class="card">
          <h3>Accuracy</h3>
          <div class="metric-value">{{ performance.accuracy }}</div>
          <div class="metric-sub">Balanced Accuracy: {{ performance.balanced_accuracy }}</div>
        </div>
        <div class="card">
          <h3>F1-Score</h3>
          <div class="metric-value">{{ performance.f1_score }}</div>
          <div class="metric-sub">Precision: {{ performance.precision }} | Recall: {{ performance.recall }}</div>
        </div>
        <div class="card">
          <h3>ROC-AUC</h3>
          <div class="metric-value">{{ performance.roc_auc }}</div>
          <div class="metric-sub">Discrimination threshold: 0.50</div>
        </div>
      </div>
    </section>

    <!-- Section 4: Fairness Assessment -->
    <section>
      <h2>4. Algorithmic Fairness & Disparate Impact (Four-Fifths Rule)</h2>
      <table>
        <thead>
          <tr>
            <th>Protected Attribute</th>
            <th>Privileged Group</th>
            <th>Disparate Impact (DI)</th>
            <th>Demographic Parity Diff</th>
            <th>Equal Opportunity Diff</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {% for f in fairness %}
          <tr>
            <td><strong>{{ f.attribute }}</strong></td>
            <td>{{ f.privileged_group }}</td>
            <td style="font-family: monospace;">{{ f.metrics.disparate_impact_ratio }}</td>
            <td style="font-family: monospace;">{{ (f.metrics.demographic_parity_difference * 100) | round(1) }}%</td>
            <td style="font-family: monospace;">{{ (f.metrics.equal_opportunity_difference * 100) | round(1) }}%</td>
            <td>
              <span class="badge {% if f.status == 'pass' %}badge-green{% elif f.status == 'warn' %}badge-amber{% else %}badge-red{% endif %}">
                {{ f.status | upper }}
              </span>
            </td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
      {% for f in fairness %}
      <div style="font-size: 12px; margin-bottom: 6px; color: #475569;">
        <strong>{{ f.attribute }} Finding:</strong> {{ f.finding }}
      </div>
      {% endfor %}
    </section>

    <!-- Section 5: Explainability -->
    <section>
      <h2>5. Global Interpretability & Proxy Leakage (SHAP)</h2>
      <div class="card" style="margin-bottom: 12px;">
        <div style="font-size: 12px; margin-bottom: 8px;">
          <strong>Explainer Type:</strong> {{ explain.explainer_type }} | <strong>Risk Level:</strong> {{ explain.status | upper }}
        </div>
        <div>{{ explain.finding }}</div>
        <div style="font-size: 11px; color: #64748b; margin-top: 6px;"><em>{{ explain.disclaimer }}</em></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>Rank</th>
            <th>Feature Name</th>
            <th>Mean |SHAP| Attribution</th>
            <th>Protected / Proxy Status</th>
          </tr>
        </thead>
        <tbody>
          {% for feat in explain.top_features %}
          <tr>
            <td>#{{ loop.index }}</td>
            <td><strong>{{ feat.feature }}</strong></td>
            <td style="font-family: monospace;">{{ feat.importance }}</td>
            <td>
              {% if feat.is_sensitive %}
                <span class="badge badge-red">PROTECTED ATTRIBUTE</span>
              {% elif feat.is_proxy %}
                <span class="badge badge-amber">SUSPECTED PROXY</span>
              {% else %}
                <span class="badge badge-green">STANDARD</span>
              {% endif %}
            </td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </section>

    <!-- Section 6: Robustness -->
    <section>
      <h2>6. Adversarial Robustness & Perturbation Stress Testing</h2>
      <div class="grid-3">
        <div class="card">
          <h3>10% Label Flip Drop</h3>
          <div class="metric-value">{{ (robustness.metric_drop_10pct * 100) | round(1) }}%</div>
          <div class="metric-sub">Pass threshold: &le; 5.0%</div>
        </div>
        <div class="card">
          <h3>5% Perturbation Flips</h3>
          <div class="metric-value">{{ (robustness.prediction_flip_rate_5pct * 100) | round(1) }}%</div>
          <div class="metric-sub">Output instability under noise</div>
        </div>
        <div class="card">
          <h3>Fairness Stability</h3>
          <div class="metric-value">&Delta; {{ robustness.fairness_stability_delta }}</div>
          <div class="metric-sub">DI drift under feature noise</div>
        </div>
      </div>
      <div style="font-size: 12px; color: #475569;">{{ robustness.finding }}</div>
    </section>

    <!-- Section 7: Regulatory Compliance Readiness -->
    <section>
      <h2>7. Regulatory Readiness: EU AI Act & India DPDP Act 2023</h2>
      <div class="grid-2">
        <div class="card">
          <h3>EU AI Act (Annex III High-Risk)</h3>
          <div class="metric-value">{{ compliance.eu_ai_act.score }} / 100</div>
          <div class="metric-sub">Points: {{ compliance.eu_ai_act.earned_points }} / {{ compliance.eu_ai_act.max_points }}</div>
          <ul style="padding-left: 18px; font-size: 11px; margin-top: 8px;">
            {% for item in compliance.eu_ai_act.checklist[:4] %}
            <li><strong>{{ item.article }}:</strong> {{ item.status | upper }} &mdash; {{ item.title }}</li>
            {% endfor %}
          </ul>
        </div>
        <div class="card">
          <h3>India DPDP Act 2023 Readiness</h3>
          <div class="metric-value">{{ compliance.dpdp_act_2023.score }} / 100</div>
          <div class="metric-sub">Points: {{ compliance.dpdp_act_2023.earned_points }} / {{ compliance.dpdp_act_2023.max_points }}</div>
          <ul style="padding-left: 18px; font-size: 11px; margin-top: 8px;">
            {% for item in compliance.dpdp_act_2023.checklist[:4] %}
            <li><strong>{{ item.section }}:</strong> {{ item.status | upper }} &mdash; {{ item.principle }}</li>
            {% endfor %}
          </ul>
        </div>
      </div>
    </section>

    <!-- Section 8: Trust Radar Scores -->
    <section>
      <h2>8. AutoAudit-360 Trust Index Breakdown</h2>
      <table>
        <thead>
          <tr>
            <th>Audit Dimension</th>
            <th>Dimension Score</th>
            <th>Benchmark Target</th>
            <th>Dimension Rating</th>
          </tr>
        </thead>
        <tbody>
          {% for axis, val in scores.dimension_scores.items() %}
          <tr>
            <td><strong>{{ axis }}</strong></td>
            <td style="font-family: monospace; font-size: 14px;"><strong>{{ val }} / 100</strong></td>
            <td>&ge; 75.0 (Pass)</td>
            <td>
              <span class="badge {% if val >= 75 %}badge-green{% elif val >= 50 %}badge-amber{% else %}badge-red{% endif %}">
                {% if val >= 75 %}COMPLIANT{% elif val >= 50 %}CONDITIONAL{% else %}DEFICIENT{% endif %}
              </span>
            </td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </section>

    <!-- Section 9: Governance & Remediation -->
    <section>
      <h2>9. Governance Disclosures & Remediation Roadmap</h2>
      <div class="card">
        <div><strong>Primary Model Owner:</strong> Risk & AI Governance Taskforce</div>
        <div><strong>Human Oversight Lead:</strong> Designated Senior Compliance Reviewer</div>
        <div><strong>Grievance Redressal Officer (DPDP Sec 13):</strong> grievance-officer@domain.example</div>
        <div><strong>Continuous Monitoring:</strong> Weekly population stability index (PSI) and demographic drift tracking.</div>
      </div>
      {% if limitations %}
      <h3 style="margin-top: 14px; font-size: 12px;">Identified Risk Limitations:</h3>
      <ul style="padding-left: 18px; font-size: 12px; color: #b91c1c;">
        {% for lim in limitations %}
        <li>{{ lim }}</li>
        {% endfor %}
      </ul>
      {% endif %}
    </section>

    <div class="footer">
      <div>
        <strong>AutoAudit-360: End-to-End Trustworthy AI Audit & Regulatory Compliance Suite</strong><br>
        Micro Project in Trustworthy and Responsible AI | SAKEC
      </div>
      <div style="text-align: right;">
        <strong>Author: VATSAL GADA</strong> | Class: TY-AIDS<br>
        PRN: 124BTAI1005 | Roll No: 12
      </div>
    </div>
  </div>

  <script>
    const auditData = {{ raw_json | safe }};
    function downloadJson() {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(auditData, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", "autoaudit360_" + auditData.meta.audit_id + ".json");
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    }
  </script>
</body>
</html>
"""

def generate_model_card_html(audit_result: Dict[str, Any]) -> str:
    """Compile audit results dictionary into a self-contained, printable HTML Model Card."""
    template = Template(MODEL_CARD_HTML_TEMPLATE)
    raw_json = json.dumps(audit_result)
    return template.render(**audit_result, raw_json=raw_json)
