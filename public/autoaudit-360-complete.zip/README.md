# AutoAudit-360: End-to-End Trustworthy AI Audit & Regulatory Compliance Suite

> **Academic Micro-Project for Trustworthy and Responsible AI**  
> **Student:** VATSAL GADA | **Class:** TY-AIDS | **PRN:** 124BTAI1005 | **Roll No:** 12  
> **Institution:** Shah & Anchor Kutchhi Engineering College (SAKEC)  
> **Domain:** AI Governance, Policy & Risk Management  
> **Syllabus Mapping:** Modules 1–4 (Trustworthy AI Pipeline, AI Model Card, EU AI Act, India DPDP Act 2023)

---

## 1. Overview & Architecture

**AutoAudit-360** is an automated assessment suite and CLI engine that audits arbitrary tabular classification models (`scikit-learn` Pipelines, estimators, or wrapped `PyTorch` models) and their underlying datasets across four core pillars:
1. **Algorithmic Fairness & Bias Mitigation** (Four-Fifths Rule, Demographic Parity, Equal Opportunity, Equalized Odds).
2. **Global Interpretability & Proxy Leakage** (TreeExplainer / Permutation SHAP attributions, proxy correlation flags).
3. **Adversarial Robustness & Stress Testing** (Synthetic label-flip corruption, feature Gaussian noise jitter, fairness stability under perturbation).
4. **Regulatory Compliance Readiness** (EU AI Act Annex III High-Risk Classification & Articles 9–15; India DPDP Act 2023 Sections 4–13, PII and minor detection).

The tool compiles an empirical **AI Model Card** conforming to international transparency standards (available as self-contained printable HTML, JSON, or PDF).

### Pipeline Flow
```
Data (CSV) & Model (.joblib/.pkl)
       │
       ▼
Data Ingestion & Integrity Hash (SHA-256)
       │
       ├─────────────────────────────────────────┐
       ▼                                         ▼
1. Fairness Auditor                      2. Explainability Auditor
   - Selection Rate per Group               - Global SHAP (Tree/Kernel)
   - Disparate Impact (80% Rule)            - Protected Attribute Leakage
   - Demographic Parity Diff                - Proxy Variable Detection
   - Equal Opportunity Diff                 - Mathematical Manifold Disclaimer
       │                                         │
       ├─────────────────────────────────────────┘
       ▼
3. Robustness & Adversarial Testing
   - Label Corruption Flips (5%, 10%, 20%)
   - Input Perturbation (Gaussian noise 1%, 5%, 10% std)
   - Prediction Flip Rate & Fairness Stability
       │
       ▼
4. Regulatory Readiness Mapping
   - EU AI Act: High-Risk Classification (Annex III) & Articles 9-15
   - India DPDP Act 2023: Consent, Notice, Accuracy, PII, Minors (<18)
   - Governance Questionnaire (15 operational inquiries)
       │
       ▼
Trust Radar Scoring (6 Axes) ──▶ Overall RAG Rating (Green / Amber / Red)
       │
       ▼
Export: Production AI Model Card (HTML / JSON / PDF)
```

---

## 2. Command Line Interface (CLI)

The core framework is directly importable in Python and executable via the command line:

```bash
python audit_model.py \
  --data demo_data/german_credit.csv \
  --target Creditability \
  --sensitive Sex,Age \
  --use_case credit_scoring \
  --out outputs/german_credit_model_card.html \
  --json_out outputs/german_credit_audit.json
```

### CLI Arguments
| Flag | Required | Default | Description |
|---|---|---|---|
| `--data` | Yes | - | Path to input dataset CSV file |
| `--target` | Yes | - | Target classification column name |
| `--sensitive` | Yes | - | Comma-separated sensitive attributes (e.g., `Sex,Age` or `race,sex`) |
| `--model` | No | `None` | Path to `.joblib` / `.pkl` scikit-learn model. *If omitted, a baseline RandomForest pipeline is trained automatically and noted in the report.* |
| `--positive_label` | No | `1` | Favorable outcome class label |
| `--use_case` | No | `credit_scoring` | Domain application key (e.g., `credit_scoring`, `employment_recruitment`, `law_enforcement_recidivism`, `education_admissions`, `insurance_health`) |
| `--out` | No | `report.html` | Destination path for printable Model Card HTML report |
| `--json_out` | No | `None` | Optional path for machine-readable raw audit JSON output |

---

## 3. PyTorch Model Wrapper & Security Notice

> ⚠️ **SECURITY WARNING:** Only upload or deserialize `.pkl` / `.joblib` models from trusted sources. Deserialization of untrusted Python bytecode can result in arbitrary remote code execution.

### Wrapping PyTorch Models for AutoAudit-360
To audit a PyTorch classification model, wrap it in a lightweight class exposing scikit-learn compatible `predict` and `predict_proba` methods:

```python
import torch
import torch.nn as nn
import numpy as np
import joblib

class PyTorchClassifierWrapper:
    """Scikit-learn compatible wrapper for PyTorch neural network classification models."""
    def __init__(self, torch_model: nn.Module, feature_names: list, device: str = "cpu"):
        self.torch_model = torch_model.to(device)
        self.torch_model.eval()
        self.feature_names = feature_names
        self.device = device

    def predict_proba(self, X):
        if hasattr(X, "values"):
            X_arr = X.values.astype(np.float32)
        else:
            X_arr = np.array(X, dtype=np.float32)
        
        tensor_x = torch.tensor(X_arr, device=self.device)
        with torch.no_grad():
            logits = self.torch_model(tensor_x)
            probs = torch.softmax(logits, dim=1).cpu().numpy()
        return probs

    def predict(self, X):
        probs = self.predict_proba(X)
        return np.argmax(probs, axis=1)

# Export for AutoAudit-360:
# wrapped = PyTorchClassifierWrapper(my_nn_model, feature_names=['col1', 'col2'])
# joblib.dump(wrapped, "my_pytorch_model.joblib")
```

---

## 4. Scoring Formulas & Mathematical Specifications

All scoring formulas are deterministic, clamped, and mathematically grounded:

### 1. Fairness Score (0–100)
$$\text{Fairness} = 100 \times \frac{1}{|A|} \sum_{a \in A} \left[ 0.5 \times \text{clamp}\left(\min\left(DI_a, \frac{1}{DI_a}\right), 0, 1\right) + 0.5 \times \left(1 - \min\left(1, \frac{\max(DPD_a, EOD_a)}{0.20}\right)\right) \right]$$
- $DI_a$: Disparate Impact ratio between unprivileged and privileged demographic subgroups.
- $DPD_a$: Demographic Parity Difference $|\text{Rate}_{\text{priv}} - \text{Rate}_{\text{unpriv}}|$.
- $EOD_a$: Equal Opportunity Difference (True Positive Rate gap) $|TPR_{\text{priv}} - TPR_{\text{unpriv}}|$.

### 2. Explainability Score (0–100)
$$\text{Explainability} = \min\left(100, \max\left(0, 100 - (20 \times N_{\text{sensitive/proxy}}) + \text{Bonus}_{\text{SHAP}}\right)\right)$$
- $N_{\text{sensitive/proxy}}$: Number of protected or high-correlation proxy variables ($r_s > 0.40$) ranked among the top 5 global SHAP features.
- $\text{Bonus}_{\text{SHAP}}$: $+10$ points awarded for successful global SHAP attribution convergence.

### 3. Robustness Score (0–100)
$$\text{Robustness} = \text{clamp}\left(100 - (\Delta_{\text{metric, 10\% flips}} \times 150) - (\text{FlipRate}_{\text{noise 5\%}} \times 150), 0, 100\right)$$
- $\Delta_{\text{metric, 10\% flips}}$: Relative metric decline (Accuracy + F1 degradation) when 10% of labels are randomly poisoned.
- $\text{FlipRate}_{\text{noise 5\%}}$: Inference switching frequency under 5% Gaussian feature jitter.

### 4. EU AI Act & India DPDP Act 2023 Readiness Scores (0–100)
$$\text{Score}_{\text{Framework}} = 100 \times \frac{\sum (w_i \times m_i)}{\sum w_i}$$
- **Weights:** Auto-verified evidence ($w = 2.0$), Self-declared questionnaires ($w = 1.0$).
- **Multipliers ($m_i$):** Yes ($m = 1.0$), Partial ($m = 0.5$), No ($m = 0.0$).

### 5. Overall Trust Score & RAG Status
$$\text{Overall Trust Score} = \frac{1}{6} \sum_{k=1}^6 \text{AxisScore}_k$$
- **Green (Certified Trustworthy):** $\ge 75.0$
- **Amber (Conditional / Review):** $50.0 - 74.9$
- **Red (Non-Compliant / High Risk):** $< 50.0$

---

## 5. Regulatory Thresholds (in `config.py`)

- **Disparate Impact (EEOC 80% Rule):**
  - Pass: $\ge 0.80$
  - Warning: $0.70 \le DI < 0.80$
  - Failure: $< 0.70$
- **Demographic Parity & Equal Opportunity Gaps:**
  - Pass: $\le 0.10$
  - Warning: $0.10 < \text{Gap} \le 0.20$
  - Failure: $> 0.20$
- **Robustness at 10% Label Poisoning:**
  - Pass: $\le 5.0\%$ relative metric loss
  - Warning: $5.0\% - 12.0\%$ metric loss
  - Failure: $> 12.0\%$ metric loss
- **Demographic Sample Threshold:** Minimum 30 observations per subgroup to eliminate small-sample noise.

---

## 6. REST API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Healthcheck and author credentials |
| `POST` | `/api/upload` | Upload CSV and optional `.joblib` model (20 MB limit) |
| `GET` | `/api/demo/<german_credit\|compas>` | Instant one-click demo data loaders |
| `POST` | `/api/audit` | Execute 4-battery audit; returns full JSON payload |
| `GET` | `/api/modelcard/<audit_id>.<html\|json>` | Download compiled Model Card |

---

## 7. Render Deployment Instructions

1. **Repository Setup:**
   - Commit `requirements.txt`, `Procfile`, `runtime.txt`, `app.py`, `audit_model.py`, `config.py`, `auditors/`, `demo_data/`, and `outputs/`.
2. **Create Web Service on Render:**
   - Go to [dashboard.render.com](https://dashboard.render.com) and click **New + > Web Service**.
   - Connect this GitHub repository.
3. **Configure Settings:**
   - **Environment:** `Python 3`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
4. **Deploy:**
   - Click **Create Web Service**. Your AutoAudit-360 live REST API and UI will be available at your designated `.onrender.com` URL.

---

## 8. Verification & Test Execution

Run the complete test suite:
```bash
python3 -m pytest -o pythonpath=. tests/ -v
```

All 7 test suites verify:
- Binned continuous age cohorts and four-fifths disparate impact calculation.
- TreeExplainer attribution and proxy correlation detection.
- Gaussian noise perturbation and label corruption sensitivity.
- PII and minors (<18) detection under DPDP Act Sec 9.
- End-to-end audit workflow and radar scoring arithmetic.

---

**AutoAudit-360** | Developed by **Vatsal Gada** (PRN: 124BTAI1005, Roll No: 12, TY-AIDS, SAKEC).  
*Diagnostic findings represent automated algorithmic measurements and do not constitute formal legal certification.*
