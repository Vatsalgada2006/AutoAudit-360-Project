"""
AutoAudit-360: End-to-End Trustworthy AI Audit & Regulatory Compliance Suite
Domain: AI Governance, Policy & Risk Management
Student: VATSAL GADA | PRN: 124BTAI1005 | Roll No: 12 | TY-AIDS (SAKEC)

Core importable framework and CLI executable.
CLI Usage:
    python audit_model.py --data data.csv --target y --sensitive sex,age --model model.joblib --out report.html
"""

import os
import sys
import argparse
import hashlib
import uuid
import datetime
from typing import Dict, Any, List, Optional, Tuple

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

from config import RANDOM_SEED, RAG_THRESHOLDS
from auditors.fairness import audit_fairness, bin_continuous_attribute
from auditors.explain import audit_explainability
from auditors.robustness import audit_robustness
from auditors.compliance import audit_compliance
from auditors.modelcard import generate_model_card_html

def train_default_pipeline(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    random_state: int = RANDOM_SEED
) -> Tuple[Pipeline, ColumnTransformer]:
    """Train a default production-grade RandomForest classification pipeline."""
    numeric_features = [c for c in X_train.columns if pd.api.types.is_numeric_dtype(X_train[c])]
    categorical_features = [c for c in X_train.columns if c not in numeric_features]

    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features)
        ],
        remainder="drop"
    )

    clf = RandomForestClassifier(n_estimators=100, max_depth=8, random_state=random_state)

    pipeline = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", clf)
    ])

    pipeline.fit(X_train, y_train)
    return pipeline, preprocessor

def run_audit(
    df: pd.DataFrame,
    target_col: str,
    sensitive_cols: List[str],
    model: Optional[Any] = None,
    positive_label: Any = 1,
    use_case: str = "credit_scoring",
    questionnaire: Optional[Dict[str, str]] = None,
    privileged_groups: Optional[Dict[str, str]] = None,
    audit_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Run full battery of trustworthy AI audits and compile production Model Card data.
    """
    audit_id = audit_id or str(uuid.uuid4())[:8]
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
    
    # 1. Dataset verification and SHA-256 hash
    csv_bytes = df.to_csv(index=False).encode('utf-8')
    dataset_hash = hashlib.sha256(csv_bytes).hexdigest()

    # Normalize target column
    if target_col not in df.columns:
        raise ValueError(f"Target column '{target_col}' not found in dataset. Available: {list(df.columns)}")

    # Detect positive label if needed
    unique_targets = df[target_col].dropna().unique()
    if positive_label not in unique_targets and len(unique_targets) == 2:
        # Default to 1 or largest value
        positive_label = unique_targets[1] if 1 in unique_targets else max(unique_targets)

    y_raw = df[target_col].values
    y = (y_raw == positive_label).astype(int)
    
    # Feature columns (exclude target)
    feature_cols = [c for c in df.columns if c != target_col]
    X = df[feature_cols].copy()

    # Train / Test Split (Stratified 80/20)
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.20, random_state=RANDOM_SEED, stratify=y
        )
    except Exception:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.20, random_state=RANDOM_SEED
        )

    # 2. Model Preparation: Use provided model or train default pipeline
    is_default_model = False
    preprocessor = None
    if model is None:
        pipeline, preprocessor = train_default_pipeline(X_train, y_train)
        model = pipeline
        is_default_model = True
        algorithm_desc = "RandomForestClassifier (Auto-trained production baseline)"
    else:
        algorithm_desc = type(model).__name__

    # Predictions & Probabilities
    try:
        y_pred_all = model.predict(X)
        y_pred_test = model.predict(X_test)
    except Exception as e:
        raise RuntimeError(f"Model failed during predict() call: {e}")

    y_proba_test = None
    if hasattr(model, "predict_proba"):
        try:
            probs = model.predict_proba(X_test)
            y_proba_test = probs[:, 1] if probs.ndim == 2 else probs
        except Exception:
            pass

    # 3. Model Performance Metrics (Balanced Accuracy & Recall for class imbalance)
    acc = float(accuracy_score(y_test, y_pred_test))
    bal_acc = float(balanced_accuracy_score(y_test, y_pred_test))
    prec = float(precision_score(y_test, y_pred_test, zero_division=0))
    rec = float(recall_score(y_test, y_pred_test, zero_division=0))
    f1 = float(f1_score(y_test, y_pred_test, zero_division=0))
    auc = float(roc_auc_score(y_test, y_proba_test)) if y_proba_test is not None and len(np.unique(y_test)) > 1 else 0.50

    performance = {
        "accuracy": round(acc, 4),
        "balanced_accuracy": round(bal_acc, 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1_score": round(f1, 4),
        "roc_auc": round(auc, 4)
    }

    # 4. Battery 1: FAIRNESS AUDIT
    fairness_results = audit_fairness(
        df=df,
        target_col=target_col,
        y_pred=y_pred_all,
        sensitive_cols=sensitive_cols,
        positive_label=positive_label,
        privileged_groups=privileged_groups
    )

    # 5. Battery 2: EXPLAINABILITY AUDIT (SHAP)
    # If pipeline has named preprocessor, extract transformed features
    X_for_shap = X_test
    if hasattr(model, "named_steps") and "preprocessor" in model.named_steps:
        prep = model.named_steps["preprocessor"]
        try:
            if hasattr(prep, "get_feature_names_out"):
                shap_features = list(prep.get_feature_names_out())
            else:
                shap_features = list(X.columns)
        except Exception:
            shap_features = list(X.columns)
    else:
        shap_features = list(X.columns)

    explain_results = audit_explainability(
        model=model,
        X=X_for_shap,
        feature_names=shap_features,
        sensitive_cols=sensitive_cols,
        preprocessor=preprocessor
    )

    # 6. Battery 3: ROBUSTNESS AUDIT
    robustness_results = audit_robustness(
        model=model,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        sensitive_col=sensitive_cols[0] if sensitive_cols else None
    )

    # 7. Battery 4: REGULATORY COMPLIANCE READINESS
    compliance_results = audit_compliance(
        use_case_key=use_case,
        fairness_results=fairness_results,
        explain_results=explain_results,
        robustness_results=robustness_results,
        df=df,
        questionnaire=questionnaire
    )

    # 8. SCORING FORMULAS (EXACT SPECIFICATION)
    # Fairness = 100 * mean over sensitive attributes of [0.5 * clamp(min(DI, 1/DI)) + 0.5 * (1 - min(1, max(DPD, EOD)/0.2))]
    fairness_scores_list = []
    for f in fairness_results:
        m = f.get("metrics", {})
        di = m.get("disparate_impact_ratio", 1.0)
        dpd = m.get("demographic_parity_difference", 0.0)
        eod = m.get("equal_opportunity_difference", 0.0)
        
        # Clamp min(DI, 1/DI) between 0 and 1
        safe_di = max(1e-5, di)
        di_term = np.clip(min(safe_di, 1.0 / safe_di), 0.0, 1.0)
        gap_term = 1.0 - min(1.0, max(dpd, eod) / 0.20)
        attr_score = 100.0 * (0.5 * di_term + 0.5 * gap_term)
        fairness_scores_list.append(attr_score)

    fairness_score = round(float(np.mean(fairness_scores_list)), 1) if fairness_scores_list else 80.0

    # Explainability = 100 - 20 per sensitive/proxy feature in the top 5 SHAP features (min 0), plus 10 bonus if SHAP ran successfully (cap 100)
    flagged = explain_results.get("flagged_count", 0)
    shap_bonus = 10.0 if explain_results.get("shap_success", True) else 0.0
    explainability_score = round(float(min(100.0, max(0.0, 100.0 - (flagged * 20.0) + shap_bonus))), 1)

    # Robustness = 100 - (avg relative metric drop at 10% label flip * 150) - (prediction flip rate at 5% noise * 150), clamped 0-100
    metric_drop_10 = robustness_results.get("metric_drop_10pct", 0.05)
    pert_flip_5 = robustness_results.get("prediction_flip_rate_5pct", 0.04)
    robustness_score = round(float(np.clip(100.0 - (metric_drop_10 * 150.0) - (pert_flip_5 * 150.0), 0.0, 100.0)), 1)

    # Compliance Scores from weighted checklists
    eu_score = round(float(compliance_results["eu_ai_act"]["score"]), 1)
    dpdp_score = round(float(compliance_results["dpdp_act_2023"]["score"]), 1)

    # Documentation completeness (% of standard Model Card sections populated)
    doc_fields = [
        bool(algorithm_desc),
        bool(use_case),
        len(fairness_results) > 0,
        len(explain_results.get("top_features", [])) > 0,
        bool(robustness_results.get("label_flip_tests")),
        len(compliance_results["eu_ai_act"]["checklist"]) >= 7,
        len(compliance_results["dpdp_act_2023"]["checklist"]) >= 7,
        bool(dataset_hash)
    ]
    doc_completeness_score = round((sum(doc_fields) / len(doc_fields)) * 100.0, 1)

    # Radar 6 axes
    radar_dimension_scores = {
        "Fairness": fairness_score,
        "Explainability": explainability_score,
        "Robustness": robustness_score,
        "EU AI Act Readiness": eu_score,
        "DPDP Act 2023 Readiness": dpdp_score,
        "Documentation Completeness": doc_completeness_score
    }

    # Overall Trust Score = Arithmetic mean of the 6 axes
    overall_trust_score = round(float(np.mean(list(radar_dimension_scores.values()))), 1)

    # RAG Status: >= 75 green, 50-74 amber, < 50 red
    if overall_trust_score >= RAG_THRESHOLDS["green"]:
        rag_status = "green"
    elif overall_trust_score >= RAG_THRESHOLDS["amber"]:
        rag_status = "amber"
    else:
        rag_status = "red"

    # Limitations & Risk Disclosures
    limitations = [
        "Audit findings reflect sample distribution characteristics and do not guarantee out-of-distribution parity.",
        "SHAP values measure empirical correlation in the trained estimator, not factual causality.",
        "Regulatory checklists represent readiness screening and do not substitute for formal legal certification.",
    ]
    if is_default_model:
        limitations.append("Note: Model was trained automatically using a standard baseline RandomForest pipeline as no external model file was supplied.")
    if flagged > 0:
        limitations.append(f"Proxy risk: {flagged} protected or correlated features exert high predictive influence.")
    if any(r.get("status") == "fail" for r in fairness_results):
        limitations.append("Severe demographic disparities detected in positive classification rates.")

    # Data Summary
    missing_cells = int(df.isnull().sum().sum())
    total_cells = int(df.shape[0] * df.shape[1])
    missing_pct = round((missing_cells / total_cells) * 100, 2) if total_cells > 0 else 0.0
    pos_rate = round(float(np.mean(y)) * 100, 2)

    data_summary = {
        "total_rows": int(len(df)),
        "total_features": int(len(feature_cols)),
        "target_column": target_col,
        "positive_label": str(positive_label),
        "positive_rate": pos_rate,
        "sensitive_attributes": sensitive_cols,
        "missing_percentage": missing_pct
    }

    meta = {
        "audit_id": audit_id,
        "timestamp": timestamp,
        "model_name": f"Model_{audit_id}",
        "algorithm": algorithm_desc,
        "is_default_trained": is_default_model,
        "framework": "scikit-learn",
        "random_seed": RANDOM_SEED,
        "dataset_hash": dataset_hash,
        "author": {
            "name": "VATSAL GADA",
            "prn": "124BTAI1005",
            "roll_no": "12",
            "class": "TY-AIDS",
            "institution": "SAKEC",
            "project": "AutoAudit-360: End-to-End Trustworthy AI Audit & Regulatory Compliance Suite"
        }
    }

    scores = {
        "overall_trust_score": overall_trust_score,
        "rag_status": rag_status,
        "dimension_scores": radar_dimension_scores
    }

    full_audit_payload = {
        "meta": meta,
        "data_summary": data_summary,
        "performance": performance,
        "fairness": fairness_results,
        "explain": explain_results,
        "robustness": robustness_results,
        "compliance": compliance_results,
        "scores": scores,
        "limitations": limitations
    }

    return full_audit_payload

def main():
    parser = argparse.ArgumentParser(description="AutoAudit-360 Trustworthy AI Assessment CLI")
    parser.add_argument("--data", required=True, help="Path to input dataset CSV file")
    parser.add_argument("--target", required=True, help="Target classification column name")
    parser.add_argument("--sensitive", required=True, help="Comma-separated sensitive attributes (e.g., 'Sex,Age')")
    parser.add_argument("--model", default=None, help="Optional path to .joblib / .pkl model file")
    parser.add_argument("--positive_label", default=1, help="Positive class label (default: 1)")
    parser.add_argument("--use_case", default="credit_scoring", help="Domain use-case (credit_scoring, employment_recruitment, law_enforcement_recidivism, etc.)")
    parser.add_argument("--out", default="report.html", help="Output path for Model Card HTML report")
    parser.add_argument("--json_out", default=None, help="Optional output path for raw audit JSON")

    args = parser.parse_args()

    if not os.path.exists(args.data):
        print(f"Error: Data file '{args.data}' does not exist.")
        sys.exit(1)

    print(f"[AutoAudit-360] Loading dataset from: {args.data}")
    df = pd.read_csv(args.data)
    sensitive_cols = [s.strip() for s in args.sensitive.split(",") if s.strip()]

    loaded_model = None
    if args.model:
        if not os.path.exists(args.model):
            print(f"Error: Model file '{args.model}' not found.")
            sys.exit(1)
        print(f"[AutoAudit-360] Loading model from: {args.model}")
        loaded_model = joblib.load(args.model)
    else:
        print("[AutoAudit-360] No model provided. Training standard RandomForest baseline...")

    # Typecast positive_label if integer
    pos_label = args.positive_label
    try:
        pos_label = int(args.positive_label)
    except ValueError:
        pass

    print("[AutoAudit-360] Initiating Trustworthy AI Audit Battery...")
    audit_results = run_audit(
        df=df,
        target_col=args.target,
        sensitive_cols=sensitive_cols,
        model=loaded_model,
        positive_label=pos_label,
        use_case=args.use_case
    )

    # Render HTML Model Card
    html_card = generate_model_card_html(audit_results)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(html_card)
    print(f"[AutoAudit-360] Model Card HTML successfully written to: {args.out}")

    if args.json_out:
        import json
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump(audit_results, f, indent=2)
        print(f"[AutoAudit-360] Audit JSON saved to: {args.json_out}")

    # Print Scored Summary
    scores = audit_results["scores"]
    print("\n" + "="*50)
    print("       AUTOAUDIT-360 AUDIT SUMMARY")
    print("="*50)
    print(f"Overall Trust Score : {scores['overall_trust_score']} / 100")
    print(f"RAG Status          : {scores['rag_status'].upper()}")
    print("-" * 50)
    for dim, val in scores["dimension_scores"].items():
        print(f" - {dim:<28}: {val:>5.1f} / 100")
    print("="*50)

if __name__ == "__main__":
    main()
