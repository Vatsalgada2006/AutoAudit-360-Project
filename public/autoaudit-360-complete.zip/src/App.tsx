/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * AutoAudit-360: End-to-End Trustworthy AI Audit & Regulatory Compliance Suite
 * Micro-Project in Trustworthy & Responsible AI
 * DESIGN CONCEPT: Forensic Regulatory Scanner & Audit Dossier (Tactile case tabs, classified dossier stamps, precision oscillogram/scanner sweep, and security clearance gauges)
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ScannerHero } from './components/ScannerHero';
import { TrustGauge } from './components/TrustGauge';
import { RadarChart } from './components/RadarChart';
import { SetupTab } from './components/Tabs/SetupTab';
import { FairnessTab } from './components/Tabs/FairnessTab';
import { ExplainabilityTab } from './components/Tabs/ExplainabilityTab';
import { RobustnessTab } from './components/Tabs/RobustnessTab';
import { ComplianceTab } from './components/Tabs/ComplianceTab';
import { ModelCardTab } from './components/Tabs/ModelCardTab';
import { PipelineTab } from './components/Tabs/PipelineTab';
import { Footer } from './components/Footer';

import { FullAuditResult } from './types';
import { GERMAN_CREDIT_AUDIT, COMPAS_AUDIT } from './data/preloadedAudits';
import {
  Sliders,
  Scale,
  Sparkles,
  Shield,
  FileCheck,
  FileText,
  Layers,
  AlertCircle,
  CheckCircle2,
  X
} from 'lucide-react';

type TabKey = 'setup' | 'fairness' | 'explainability' | 'robustness' | 'compliance' | 'modelcard' | 'pipeline';

export default function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [activeTab, setActiveTab] = useState<TabKey>('setup');
  
  // Active audit results (Default to pre-audited German Credit dataset)
  const [auditResult, setAuditResult] = useState<FullAuditResult>(GERMAN_CREDIT_AUDIT);
  
  // Auditing lifecycle
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditStage, setAuditStage] = useState(0);

  // Setup form states
  const [datasetId, setDatasetId] = useState('demo_german_credit');
  const [columns, setColumns] = useState<string[]>([
    'Creditability', 'Age', 'Sex', 'Foreign_Worker', 'Duration_Months',
    'Credit_Amount', 'Account_Status', 'Savings_Account', 'Employment_Duration',
    'Housing', 'Job', 'Credit_History'
  ]);
  const [dtypes, setDtypes] = useState<Record<string, string>>({
    Creditability: 'numeric',
    Age: 'numeric',
    Sex: 'categorical',
    Foreign_Worker: 'categorical',
    Duration_Months: 'numeric',
    Credit_Amount: 'numeric',
    Account_Status: 'categorical',
    Savings_Account: 'categorical',
    Employment_Duration: 'categorical',
    Housing: 'categorical',
    Job: 'categorical',
    Credit_History: 'categorical'
  });
  const [targetCol, setTargetCol] = useState('Creditability');
  const [positiveLabel, setPositiveLabel] = useState('1');
  const [sensitiveCols, setSensitiveCols] = useState<string[]>(['Sex', 'Age']);
  const [useCase, setUseCase] = useState('credit_scoring');
  const [questionnaire, setQuestionnaire] = useState<Record<string, string>>({
    q1_risk_mgmt: 'yes',
    q2_data_prep: 'yes',
    q3_human_oversight: 'yes',
    q4_logging: 'yes',
    q5_transparency: 'yes',
    q6_cybersecurity: 'partial',
    q7_dpdp_notice: 'yes',
    q8_dpdp_consent: 'yes',
    q9_dpdp_erasure: 'partial',
    q10_dpdp_grievance: 'yes',
    q11_dpdp_breach: 'yes',
    q12_dpdp_dpo: 'partial',
    q13_dpdp_dpia: 'partial',
    q14_dpdp_minors: 'yes',
    q15_human_training: 'yes'
  });

  const [uploadedFileName, setUploadedFileName] = useState<string | undefined>('german_credit.csv (Demo)');
  const [uploadedModelName, setUploadedModelName] = useState<string | undefined>();
  const [toast, setToast] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>({
    type: 'info',
    message: 'German Credit demo loaded. Switch tabs to explore or click "Audit COMPAS" to run another assessment.'
  });

  // Auto-dismiss toast after 6 seconds
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 6000);
      return () => clearInterval(timer);
    }
  }, [toast]);

  // Handle Demo Loaders
  const handleRunDemo = async (demoName: 'german_credit' | 'compas') => {
    setIsAuditing(true);
    setAuditStage(0);
    setToast({ type: 'info', message: `Initializing ${demoName === 'german_credit' ? 'German Credit Lending' : 'COMPAS Recidivism'} Audit...` });

    // Try API fetch or fallback to bundled instant result
    try {
      // Step progression simulation
      const stageTimer = setInterval(() => {
        setAuditStage(prev => {
          if (prev >= 5) {
            clearInterval(stageTimer);
            return 5;
          }
          return prev + 1;
        });
      }, 500);

      const res = await fetch(`/api/demo/${demoName}`);
      if (res.ok) {
        const demoData = await res.json();
        setDatasetId(demoData.dataset_id);
        setColumns(demoData.columns);
        setDtypes(demoData.dtypes);
        setTargetCol(demoData.default_target);
        setPositiveLabel(String(demoData.default_positive));
        setSensitiveCols(demoData.default_sensitive);
        setUseCase(demoData.default_use_case);
        setUploadedFileName(`${demoName}.csv`);
      }

      // Check bundled audit
      setTimeout(() => {
        clearInterval(stageTimer);
        setIsAuditing(false);
        const result = demoName === 'german_credit' ? GERMAN_CREDIT_AUDIT : COMPAS_AUDIT;
        setAuditResult(result);
        if (demoName === 'compas') {
          setColumns(['two_year_recid', 'Low_Risk_Outcome', 'race', 'sex', 'age', 'age_cat', 'priors_count', 'juv_fel_count', 'juv_misd_count', 'c_charge_degree']);
          setTargetCol('Low_Risk_Outcome');
          setPositiveLabel('1');
          setSensitiveCols(['race', 'sex']);
          setUseCase('law_enforcement_recidivism');
          setUploadedFileName('compas.csv (Demo)');
        } else {
          setColumns(['Creditability', 'Age', 'Sex', 'Foreign_Worker', 'Duration_Months', 'Credit_Amount', 'Account_Status', 'Savings_Account', 'Employment_Duration', 'Housing', 'Job', 'Credit_History']);
          setTargetCol('Creditability');
          setPositiveLabel('1');
          setSensitiveCols(['Sex', 'Age']);
          setUseCase('credit_scoring');
          setUploadedFileName('german_credit.csv (Demo)');
        }
        setActiveTab('fairness');
        setToast({ type: 'success', message: `Successfully audited ${demoName === 'german_credit' ? 'German Credit' : 'COMPAS'}! Trust Score: ${result.scores.overall_trust_score}/100` });
      }, 2800);

    } catch (err) {
      setIsAuditing(false);
      const result = demoName === 'german_credit' ? GERMAN_CREDIT_AUDIT : COMPAS_AUDIT;
      setAuditResult(result);
      setActiveTab('fairness');
    }
  };

  // Handle CSV Upload
  const handleUploadFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 20 * 1024 * 1024) {
      setToast({ type: 'error', message: 'File size exceeds 20 MB limit.' });
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    setUploadedFileName(file.name);
    setToast({ type: 'info', message: `Uploading ${file.name}...` });

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to upload file');
      }

      const data = await res.json();
      setDatasetId(data.dataset_id);
      setColumns(data.columns);
      setDtypes(data.dtypes);
      if (data.columns.length > 0) {
        setTargetCol(data.columns[0]);
      }
      setToast({ type: 'success', message: `Uploaded ${file.name} successfully (${data.row_count} rows, ${data.columns.length} columns).` });
    } catch (err: any) {
      setToast({ type: 'error', message: `Upload error: ${err.message}` });
    }
  };

  // Handle Model Upload
  const handleUploadModel = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.joblib') && !file.name.endsWith('.pkl')) {
      setToast({ type: 'error', message: 'Model file must be .joblib or .pkl.' });
      return;
    }

    setUploadedModelName(file.name);
    setToast({ type: 'info', message: `Selected custom model: ${file.name}` });
  };

  // Run Full Audit Action
  const handleRunAudit = async () => {
    if (sensitiveCols.length === 0) {
      setToast({ type: 'error', message: 'Please select at least one sensitive attribute.' });
      return;
    }

    setIsAuditing(true);
    setAuditStage(0);

    const stageTimer = setInterval(() => {
      setAuditStage(prev => (prev < 5 ? prev + 1 : 5));
    }, 600);

    try {
      const payload = {
        dataset_id: datasetId,
        target: targetCol,
        positive_label: positiveLabel,
        sensitive: sensitiveCols,
        use_case: useCase,
        questionnaire: questionnaire
      };

      const res = await fetch('/api/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Audit execution failed');
      }

      const auditData = await res.json();
      clearInterval(stageTimer);
      setIsAuditing(false);
      setAuditResult(auditData);
      setActiveTab('fairness');
      setToast({ type: 'success', message: `Audit completed! Overall Trust Score: ${auditData.scores.overall_trust_score}/100 (${auditData.scores.rag_status.toUpperCase()})` });

    } catch (err: any) {
      clearInterval(stageTimer);
      setIsAuditing(false);
      setToast({ type: 'error', message: `Audit error: ${err.message}` });
    }
  };

  const navTabs: Array<{ key: TabKey; label: string; icon: React.FC<{ size?: number; className?: string }> }> = [
    { key: 'setup', label: 'Setup & Ingestion', icon: Sliders },
    { key: 'fairness', label: 'Fairness & Bias', icon: Scale },
    { key: 'explainability', label: 'SHAP & Proxies', icon: Sparkles },
    { key: 'robustness', label: 'Adversarial & Noise', icon: Shield },
    { key: 'compliance', label: 'EU AI & DPDP 2023', icon: FileCheck },
    { key: 'modelcard', label: 'AI Model Card', icon: FileText },
    { key: 'pipeline', label: 'Architecture', icon: Layers },
  ];

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'} flex flex-col font-sans transition-colors duration-200`}>
      
      {/* Global Header */}
      <Header
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onRunDemo={handleRunDemo}
        isAuditing={isAuditing}
        overallScore={auditResult?.scores?.overall_trust_score}
        ragStatus={auditResult?.scores?.rag_status}
      />

      {/* Floating Toast Notification */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 max-w-md p-3.5 rounded-xl border shadow-2xl flex items-start gap-3 backdrop-blur-md transition-all ${
          toast.type === 'success'
            ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-200'
            : toast.type === 'error'
            ? 'bg-rose-950/90 border-rose-500/40 text-rose-200'
            : 'bg-slate-900/90 border-slate-700 text-slate-200'
        }`}>
          {toast.type === 'success' ? (
            <CheckCircle2 size={18} className="text-emerald-400 shrink-0 mt-0.5" />
          ) : toast.type === 'error' ? (
            <AlertCircle size={18} className="text-rose-400 shrink-0 mt-0.5" />
          ) : (
            <Sparkles size={18} className="text-amber-400 shrink-0 mt-0.5" />
          )}
          <p className="text-xs font-sans leading-relaxed flex-1">{toast.message}</p>
          <button
            onClick={() => setToast(null)}
            className="text-slate-400 hover:text-white p-0.5"
            aria-label="Dismiss toast"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-6">
        
        {/* Animated Forensic Scanner Hero (Shows during active audit run) */}
        {isAuditing && (
          <ScannerHero currentStage={auditStage} totalStages={6} stageName="" />
        )}

        {/* Top Summary Bar: Trust Score Gauge & Radar Profile */}
        {auditResult && !isAuditing && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
            <div className="lg:col-span-7">
              <TrustGauge scores={auditResult.scores} />
            </div>
            <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1">
                <span className="font-display font-bold text-white text-xs uppercase tracking-wider">
                  Trust Radar Hexagon (6 Dimensions)
                </span>
                <span className="text-[10px] font-mono text-cyan-400">
                  Target: &ge;75.0 Benchmark
                </span>
              </div>
              <RadarChart scores={auditResult.scores} darkMode={darkMode} />
            </div>
          </div>
        )}

        {/* Case Dossier Tabs Bar */}
        <div className="flex border-b border-slate-800 overflow-x-auto gap-1 mb-8 no-scrollbar">
          {navTabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveTab(tab.key)}
                className={`py-3 px-4 font-display text-xs sm:text-sm font-bold flex items-center gap-2 border-b-2 transition-all whitespace-nowrap ${
                  isActive
                    ? 'border-amber-400 text-amber-400 bg-amber-400/5'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <Icon size={16} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Panes */}
        <div className="transition-all duration-300">
          {activeTab === 'setup' && (
            <SetupTab
              columns={columns}
              dtypes={dtypes}
              targetCol={targetCol}
              setTargetCol={setTargetCol}
              positiveLabel={positiveLabel}
              setPositiveLabel={setPositiveLabel}
              sensitiveCols={sensitiveCols}
              setSensitiveCols={setSensitiveCols}
              useCase={useCase}
              setUseCase={setUseCase}
              questionnaire={questionnaire}
              setQuestionnaire={setQuestionnaire}
              onUploadFile={handleUploadFile}
              onUploadModel={handleUploadModel}
              onRunAudit={handleRunAudit}
              onRunDemo={handleRunDemo}
              isAuditing={isAuditing}
              uploadedFileName={uploadedFileName}
              uploadedModelName={uploadedModelName}
            />
          )}

          {activeTab === 'fairness' && (
            <FairnessTab fairnessData={auditResult.fairness} darkMode={darkMode} />
          )}

          {activeTab === 'explainability' && (
            <ExplainabilityTab explainData={auditResult.explain} darkMode={darkMode} />
          )}

          {activeTab === 'robustness' && (
            <RobustnessTab robustnessData={auditResult.robustness} darkMode={darkMode} />
          )}

          {activeTab === 'compliance' && (
            <ComplianceTab complianceData={auditResult.compliance} />
          )}

          {activeTab === 'modelcard' && (
            <ModelCardTab auditResult={auditResult} />
          )}

          {activeTab === 'pipeline' && (
            <PipelineTab />
          )}
        </div>

      </main>

      {/* Global Academic Certification Footer */}
      <Footer />

    </div>
  );
}
