import React from 'react';
import { ShieldCheck, BookOpen, Award } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-800 bg-slate-950 py-8 px-4 lg:px-8 mt-12 text-slate-400 font-sans">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs">
        
        {/* Left: Project & Syllabus Info */}
        <div className="text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2 text-white font-display font-bold text-sm">
            <ShieldCheck size={16} className="text-amber-400" />
            AutoAudit-360: End-to-End Trustworthy AI Audit & Regulatory Compliance Suite
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Academic Micro-Project for Trustworthy & Responsible AI (SAKEC) &bull; Modules 1–4 (Pipeline, Model Card, EU AI Act, India DPDP Act 2023)
          </p>
        </div>

        {/* Right: Mandatory Student Credentials as specified */}
        <div className="text-center md:text-right font-mono bg-slate-900/80 border border-slate-800 p-3 rounded-lg">
          <div className="text-amber-300 font-bold tracking-wider uppercase text-[11px]">
            VATSAL GADA | TY-AIDS | PRN 124BTAI1005 | Roll No 12
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            AutoAudit-360, Micro Project in Trustworthy and Responsible AI
          </div>
        </div>

      </div>

      <div className="max-w-7xl mx-auto mt-6 pt-4 border-t border-slate-900 text-center text-[11px] text-slate-400">
        Empirical diagnostic audit suite &bull; Adheres to EEOC Uniform Guidelines &bull; EU AI Act Annex III &bull; Digital Personal Data Protection Act 2023
      </div>
    </footer>
  );
};
