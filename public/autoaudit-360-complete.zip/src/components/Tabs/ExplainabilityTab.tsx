import React from 'react';
import { ExplainabilityAudit } from '../../types';
import { AlertCircle, AlertTriangle, CheckCircle, Info, Key, ShieldCheck, Sparkles, XCircle } from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

interface ExplainabilityTabProps {
  explainData: ExplainabilityAudit;
  darkMode?: boolean;
}

export const ExplainabilityTab: React.FC<ExplainabilityTabProps> = ({ explainData, darkMode = true }) => {
  if (!explainData) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
        No Explainability audit data available.
      </div>
    );
  }

  const { status, severity, explainer_type, finding, disclaimer, top_features, sensitive_in_top_5, proxies_in_top_5, chart_data } = explainData;

  const barData = {
    labels: chart_data.labels,
    datasets: [
      {
        label: 'Mean |SHAP| Attribution Value',
        data: chart_data.values,
        backgroundColor: chart_data.labels.map(l => {
          const match = top_features.find(f => f.feature === l);
          if (match?.is_sensitive) return 'rgba(239, 68, 68, 0.8)';
          if (match?.is_proxy) return 'rgba(245, 158, 11, 0.8)';
          return 'rgba(6, 182, 212, 0.7)';
        }),
        borderColor: chart_data.labels.map(l => {
          const match = top_features.find(f => f.feature === l);
          if (match?.is_sensitive) return '#EF4444';
          if (match?.is_proxy) return '#F59E0B';
          return '#06B6D4';
        }),
        borderWidth: 1.5,
        borderRadius: 4,
      }
    ]
  };

  const barOptions = {
    indexAxis: 'y' as const, // horizontal bar chart for feature attributions
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        beginAtZero: true,
        ticks: {
          color: darkMode ? '#94a3b8' : '#64748b',
          font: { family: "'JetBrains Mono', monospace", size: 10 }
        },
        grid: {
          color: darkMode ? 'rgba(148, 163, 184, 0.1)' : 'rgba(0, 0, 0, 0.06)'
        }
      },
      y: {
        ticks: {
          color: darkMode ? '#cbd5e1' : '#334155',
          font: { family: "'Space Grotesk', system-ui", size: 11, weight: 600 as const }
        },
        grid: { display: false }
      }
    },
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: darkMode ? '#0f172a' : '#ffffff',
        titleColor: darkMode ? '#f8fafc' : '#0f172a',
        bodyColor: darkMode ? '#cbd5e1' : '#334155',
        borderColor: darkMode ? '#334155' : '#cbd5e1',
        borderWidth: 1,
        callbacks: {
          label: (ctx: any) => `Mean |SHAP|: ${ctx.raw}`
        }
      }
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner Status */}
      <div className={`p-5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
        status === 'pass'
          ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200'
          : status === 'warn'
          ? 'bg-amber-950/30 border-amber-500/30 text-amber-200'
          : 'bg-rose-950/30 border-rose-500/30 text-rose-200'
      }`}>
        <div className="flex items-start gap-3">
          {status === 'pass' ? (
            <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
          ) : status === 'warn' ? (
            <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
          ) : (
            <XCircle className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider">
                Explainability & Leakage Verdict: {status.toUpperCase()}
              </span>
              <span className="text-[11px] font-mono px-2 py-0.2 rounded bg-black/30 border border-current">
                Engine: {explainer_type}
              </span>
            </div>
            <p className="text-sm font-sans mt-1 text-slate-200">
              {finding}
            </p>
          </div>
        </div>

        <div className="font-mono text-xs uppercase px-3 py-1.5 rounded-lg bg-black/40 border border-slate-700/80 shrink-0">
          Severity: <strong className="text-white">{severity.toUpperCase()}</strong>
        </div>
      </div>

      {/* Critical Statutory Disclaimer Banner */}
      <div className="bg-cyan-950/30 border-l-4 border-cyan-400 p-4 rounded-r-xl text-xs text-cyan-200 flex items-start gap-2.5">
        <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <strong className="font-mono uppercase text-cyan-300">Causality & Manifold Disclaimer:</strong>
          <p className="mt-0.5 leading-relaxed font-sans">
            {disclaimer}
          </p>
        </div>
      </div>

      {/* Main Bar Chart: Global Feature Importance */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-4">
          <div>
            <h4 className="font-display font-bold text-white text-base">
              Global Feature Attributions (Mean |SHAP|)
            </h4>
            <p className="text-xs text-slate-400">
              Ranking features by global magnitude of predictive attribution. Color coding indicates sensitive leakage or proxy risks.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-rose-400">
              <span className="w-2.5 h-2.5 rounded bg-rose-500" /> Protected
            </span>
            <span className="flex items-center gap-1.5 text-amber-400">
              <span className="w-2.5 h-2.5 rounded bg-amber-500" /> Suspected Proxy
            </span>
            <span className="flex items-center gap-1.5 text-cyan-400">
              <span className="w-2.5 h-2.5 rounded bg-cyan-500" /> Standard
            </span>
          </div>
        </div>

        <div className="w-full h-80 sm:h-96">
          {/* @ts-ignore */}
          <Bar data={barData} options={barOptions} />
        </div>
      </div>

      {/* Top 5 Feature Table with Proxy Analysis */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md">
        <h4 className="font-display font-bold text-white text-base mb-3">
          Top Influential Features & Proxy Correlation Analysis
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[11px]">
                <th className="py-2.5 px-3">Rank</th>
                <th className="py-2.5 px-3">Feature Name</th>
                <th className="py-2.5 px-3">Attribution (|SHAP|)</th>
                <th className="py-2.5 px-3">Classification</th>
                <th className="py-2.5 px-3">Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-200">
              {top_features.map((feat, idx) => {
                const proxyInfo = proxies_in_top_5.find(p => p.feature === feat.feature);
                return (
                  <tr key={feat.feature} className={feat.is_sensitive ? 'bg-rose-950/20' : feat.is_proxy ? 'bg-amber-950/20' : ''}>
                    <td className="py-2.5 px-3 font-bold text-slate-400">#{idx + 1}</td>
                    <td className="py-2.5 px-3 font-semibold text-white">{feat.feature}</td>
                    <td className="py-2.5 px-3 font-bold text-cyan-400">{feat.importance.toFixed(4)}</td>
                    <td className="py-2.5 px-3">
                      {feat.is_sensitive ? (
                        <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] uppercase font-bold">
                          Protected Attribute
                        </span>
                      ) : feat.is_proxy ? (
                        <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] uppercase font-bold">
                          Proxy Variable
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] uppercase font-semibold">
                          Permitted
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300 text-[11px] font-sans">
                      {feat.is_sensitive ? (
                        <span className="text-rose-300">Direct protected demographic used in decision boundary.</span>
                      ) : proxyInfo ? (
                        <span className="text-amber-300">
                          Spearman corr <strong>{proxyInfo.correlation}</strong> with protected attribute <em>{proxyInfo.sensitive_attribute}</em>.
                        </span>
                      ) : (
                        <span className="text-slate-500">No severe demographic correlation identified.</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reviewer Notes & Limitations */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-slate-400">
        <h5 className="font-mono uppercase font-bold text-slate-300 mb-1 flex items-center gap-1.5">
          <Info size={14} className="text-amber-400" /> Reviewer Notes & Interpretability Boundaries:
        </h5>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            SHAP assigns cooperative game theory Shapley values to features, demonstrating which inputs shift predictions from baseline expectation. High attribution does not imply causal culpability in an adverse decision.
          </li>
          <li>
            Proxy detection calculates pairwise Spearman rank correlation ($r_s \ge 0.40$) against protected columns. A feature exhibiting high proxy correlation requires validation against legitimate business necessity.
          </li>
        </ul>
      </div>

    </div>
  );
};
