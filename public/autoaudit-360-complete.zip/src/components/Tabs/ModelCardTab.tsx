import React from 'react';
import { FullAuditResult } from '../../types';
import { Download, Printer, FileText, FileCode, CheckCircle, Shield, Info } from 'lucide-react';

interface ModelCardTabProps {
  auditResult: FullAuditResult;
}

export const ModelCardTab: React.FC<ModelCardTabProps> = ({ auditResult }) => {
  if (!auditResult) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
        No Model Card compiled yet.
      </div>
    );
  }

  const { meta, data_summary, performance, fairness, explain, robustness, compliance, scores, limitations } = auditResult;

  const downloadHtmlReport = () => {
    // Generate self-contained downloadable HTML blob directly on client
    const auditId = meta.audit_id;
    // Attempt download from API or trigger client-side blob download
    const url = `/api/modelcard/${auditId}.html`;
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `modelcard_${auditId}.html`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
  };

  const downloadJsonReport = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(auditResult, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `autoaudit360_${meta.audit_id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      
      {/* Top Action Bar: Export Buttons */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 print:hidden">
        <div>
          <h3 className="font-display font-bold text-white text-base flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            AI Model Card Compilation
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit ID: <code className="text-amber-300 font-mono">{meta.audit_id}</code> | SHA-256: <code className="text-slate-400 font-mono">{meta.dataset_hash.slice(0, 16)}...</code>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={downloadHtmlReport}
            className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Download size={14} /> Download HTML Report
          </button>

          <button
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Printer size={14} /> Print / Save as PDF
          </button>

          <button
            onClick={downloadJsonReport}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
          >
            <FileCode size={14} /> Download JSON
          </button>
        </div>
      </div>

      {/* Printable Model Card Canvas (Styled for high contrast and printable paper layout) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 sm:p-8 shadow-xl text-slate-200 print:bg-white print:text-black print:border-none print:p-0">
        
        {/* Document Header */}
        <div className="border-b-2 border-slate-700 pb-5 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400 print:text-slate-800 font-bold block mb-1">
              AUTOAUDIT-360 &bull; PRODUCTION AI MODEL CARD
            </span>
            <h2 className="text-2xl font-bold font-display text-white print:text-black">
              System Specification: {meta.model_name}
            </h2>
            <div className="text-xs font-mono text-slate-400 print:text-slate-600 mt-1 flex flex-wrap gap-3">
              <span>Timestamp: {meta.timestamp}</span>
              <span>Framework: {meta.framework}</span>
              <span>Deterministic Seed: {meta.random_seed}</span>
            </div>
          </div>

          <div className="text-right">
            <div className={`stamp-badge ${
              scores.rag_status === 'green' ? 'stamp-pass' : scores.rag_status === 'amber' ? 'stamp-warn' : 'stamp-fail'
            }`}>
              {scores.rag_status === 'green' ? 'CERTIFIED PASS' : scores.rag_status === 'amber' ? 'CONDITIONAL REVIEW' : 'HIGH RISK FAIL'}
            </div>
            <div className="text-xs font-mono text-slate-400 print:text-slate-700 mt-1 font-bold">
              Trust Score: {scores.overall_trust_score} / 100
            </div>
          </div>
        </div>

        {/* Legal Disclaimer Box */}
        <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-400 mb-6 print:border-slate-300 print:bg-slate-50 print:text-slate-800">
          <strong>Regulatory Transparency Notice:</strong> This AI Model Card compiles automated empirical audit findings and operational disclosures. Wording reflects diagnostic assessments; it does <em>not</em> constitute a formal legal conformity certificate.
        </div>

        {/* Section 1: Model Details & Intended Use */}
        <section className="mb-6">
          <h3 className="font-display font-bold text-white print:text-black text-sm uppercase tracking-wider border-b border-slate-800 pb-2 mb-3">
            1. Model Architecture & Scope of Use
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div className="p-3 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <div className="text-slate-400">Algorithm:</div>
              <div className="text-white print:text-black font-semibold mt-0.5">{meta.algorithm}</div>
              <div className="text-slate-400 mt-2">Target Variable:</div>
              <div className="text-amber-400 print:text-black font-semibold mt-0.5">{data_summary.target_column} (Positive Label: {data_summary.positive_label})</div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <div className="text-slate-400">Intended Application:</div>
              <div className="text-white print:text-black font-semibold mt-0.5">{compliance.use_case.title}</div>
              <div className="text-slate-400 mt-2">EU AI Act Classification:</div>
              <div className="text-cyan-400 print:text-black font-semibold mt-0.5">{compliance.eu_ai_act.classification}</div>
            </div>
          </div>
        </section>

        {/* Section 2: Dataset & Performance Metrics */}
        <section className="mb-6">
          <h3 className="font-display font-bold text-white print:text-black text-sm uppercase tracking-wider border-b border-slate-800 pb-2 mb-3">
            2. Dataset Summary & Quantitative Performance
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <span className="text-slate-400 block text-[10px]">Dataset Scale:</span>
              <span className="text-white print:text-black font-bold text-base">{data_summary.total_rows} rows</span>
              <span className="text-slate-500 block text-[10px]">{data_summary.total_features} features, {data_summary.missing_percentage}% missing</span>
            </div>

            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <span className="text-slate-400 block text-[10px]">Accuracy / Balanced:</span>
              <span className="text-white print:text-black font-bold text-base">{(performance.accuracy * 100).toFixed(1)}%</span>
              <span className="text-slate-500 block text-[10px]">Balanced: {(performance.balanced_accuracy * 100).toFixed(1)}%</span>
            </div>

            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <span className="text-slate-400 block text-[10px]">Precision & Recall:</span>
              <span className="text-white print:text-black font-bold text-base">{(performance.f1_score * 100).toFixed(1)}% F1</span>
              <span className="text-slate-500 block text-[10px]">P: {(performance.precision * 100).toFixed(0)}% | R: {(performance.recall * 100).toFixed(0)}%</span>
            </div>

            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <span className="text-slate-400 block text-[10px]">Discrimination (AUC):</span>
              <span className="text-white print:text-black font-bold text-base">{performance.roc_auc.toFixed(3)}</span>
              <span className="text-slate-500 block text-[10px]">ROC-AUC Metric</span>
            </div>
          </div>
        </section>

        {/* Section 3: Fairness & Disparate Impact */}
        <section className="mb-6">
          <h3 className="font-display font-bold text-white print:text-black text-sm uppercase tracking-wider border-b border-slate-800 pb-2 mb-3">
            3. Algorithmic Fairness & Disparate Impact (Four-Fifths Rule)
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                  <th className="py-2">Attribute</th>
                  <th className="py-2">Privileged Baseline</th>
                  <th className="py-2">Disparate Impact (DI)</th>
                  <th className="py-2">Demographic Parity Diff</th>
                  <th className="py-2">Equal Opportunity Diff</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200 print:text-black">
                {fairness.map(f => (
                  <tr key={f.attribute}>
                    <td className="py-2 font-semibold text-white print:text-black">{f.attribute}</td>
                    <td className="py-2 text-slate-400 print:text-slate-700">{f.privileged_group}</td>
                    <td className="py-2 font-bold">{f.metrics.disparate_impact_ratio.toFixed(3)}</td>
                    <td className="py-2">{(f.metrics.demographic_parity_difference * 100).toFixed(1)}%</td>
                    <td className="py-2">{(f.metrics.equal_opportunity_difference * 100).toFixed(1)}%</td>
                    <td className="py-2 font-bold uppercase">{f.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Section 4: Explainability & Robustness Summary */}
        <section className="mb-6">
          <h3 className="font-display font-bold text-white print:text-black text-sm uppercase tracking-wider border-b border-slate-800 pb-2 mb-3">
            4. Interpretability (SHAP) & Adversarial Robustness
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <div className="font-bold text-white print:text-black font-display mb-1">Global Attribution:</div>
              <div className="text-slate-300 print:text-slate-800 mb-2">{explain.finding}</div>
              <div className="text-[11px] text-slate-400 font-mono">
                Top 3 features: {explain.top_features.slice(0, 3).map(f => f.feature).join(', ')}
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <div className="font-bold text-white print:text-black font-display mb-1">Adversarial Resilience:</div>
              <div className="text-slate-300 print:text-slate-800 mb-2">{robustness.finding}</div>
              <div className="text-[11px] text-slate-400 font-mono">
                10% Label flip drop: {(robustness.metric_drop_10pct * 100).toFixed(1)}% | Noise flip rate: {(robustness.prediction_flip_rate_5pct * 100).toFixed(1)}%
              </div>
            </div>
          </div>
        </section>

        {/* Section 5: Regulatory Compliance Breakdown */}
        <section className="mb-6">
          <h3 className="font-display font-bold text-white print:text-black text-sm uppercase tracking-wider border-b border-slate-800 pb-2 mb-3">
            5. Regulatory Readiness & Governance Disclosures
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div className="p-3 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <div className="text-amber-400 font-bold mb-1">EU AI Act Readiness: {compliance.eu_ai_act.score}/100</div>
              <div className="text-slate-300 print:text-slate-800 text-[11px] font-sans">
                Articles 9 (Risk Mgmt), 10 (Bias Data), 11 (Documentation), 12 (Logs), 13 (Transparency), 14 (Human Oversight), 15 (Robustness) examined.
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 print:bg-slate-50 print:border-slate-300">
              <div className="text-cyan-400 font-bold mb-1">India DPDP Act 2023 Readiness: {compliance.dpdp_act_2023.score}/100</div>
              <div className="text-slate-300 print:text-slate-800 text-[11px] font-sans">
                Notice, consent architecture, data accuracy (Sec 8), minor protection (Sec 9), and grievance redressal verified.
              </div>
            </div>
          </div>
        </section>

        {/* Section 6: Identified Limitations & Risk Mitigations */}
        <section className="mb-6">
          <h3 className="font-display font-bold text-white print:text-black text-sm uppercase tracking-wider border-b border-slate-800 pb-2 mb-3">
            6. Known Limitations & Recommendations
          </h3>
          <ul className="list-disc pl-5 space-y-1 text-xs text-slate-300 print:text-slate-800 font-sans">
            {limitations.map((lim, idx) => (
              <li key={idx}>{lim}</li>
            ))}
          </ul>
        </section>

        {/* Academic Seal Footer */}
        <div className="mt-8 pt-5 border-t-2 border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs font-mono text-slate-400 print:text-slate-700">
          <div>
            <strong>AutoAudit-360 Trustworthy AI Suite</strong> &bull; Micro-Project in Trustworthy & Responsible AI
          </div>
          <div className="text-right">
            <strong>Author: VATSAL GADA</strong> &bull; TY-AIDS &bull; Roll No: 12 &bull; PRN: 124BTAI1005 (SAKEC)
          </div>
        </div>

      </div>

    </div>
  );
};
