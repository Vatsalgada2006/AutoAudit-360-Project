import React, { useState } from 'react';
import { FairnessAuditItem } from '../../types';
import { AlertTriangle, CheckCircle, Info, Scale, ShieldCheck, XCircle } from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

interface FairnessTabProps {
  fairnessData: FairnessAuditItem[];
  darkMode?: boolean;
}

export const FairnessTab: React.FC<FairnessTabProps> = ({ fairnessData, darkMode = true }) => {
  const [selectedAttrIndex, setSelectedAttrIndex] = useState(0);

  if (!fairnessData || fairnessData.length === 0) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center">
        <Scale className="w-10 h-10 text-slate-500 mx-auto mb-2" />
        <h3 className="font-display font-bold text-white text-base">No Fairness Audit Run Yet</h3>
        <p className="text-xs text-slate-400 mt-1">
          Select sensitive attributes in the Setup tab and click "Run Full Audit" or launch a 1-click Demo.
        </p>
      </div>
    );
  }

  const currentItem = fairnessData[selectedAttrIndex] || fairnessData[0];
  const { metrics, chart_data, subgroup_breakdown, small_group_warnings } = currentItem;

  // Bar Chart with 80% line overlay
  const barChartData = {
    labels: chart_data.labels,
    datasets: [
      {
        label: 'Subgroup Selection Rate (%)',
        data: chart_data.selection_rates_pct,
        backgroundColor: chart_data.labels.map(l =>
          l === currentItem.privileged_group ? 'rgba(16, 185, 129, 0.7)' : 'rgba(245, 158, 11, 0.7)'
        ),
        borderColor: chart_data.labels.map(l =>
          l === currentItem.privileged_group ? '#10B981' : '#F59E0B'
        ),
        borderWidth: 1.5,
        borderRadius: 4,
      },
      {
        type: 'line' as const,
        label: `EEOC 80% Rule Baseline (${chart_data.eighty_percent_line_pct}%)`,
        data: chart_data.labels.map(() => chart_data.eighty_percent_line_pct),
        borderColor: '#EF4444',
        borderWidth: 2,
        borderDash: [5, 5],
        pointRadius: 0,
        fill: false,
      }
    ]
  };

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        ticks: {
          callback: (val: any) => `${val}%`,
          color: darkMode ? '#94a3b8' : '#64748b',
          font: { family: "'JetBrains Mono', monospace", size: 10 }
        },
        grid: {
          color: darkMode ? 'rgba(148, 163, 184, 0.1)' : 'rgba(0, 0, 0, 0.06)'
        }
      },
      x: {
        ticks: {
          color: darkMode ? '#cbd5e1' : '#334155',
          font: { family: "'Space Grotesk', system-ui", size: 11, weight: 600 as const }
        },
        grid: { display: false }
      }
    },
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: darkMode ? '#e2e8f0' : '#1e293b',
          font: { family: "'Plus Jakarta Sans', system-ui", size: 11 }
        }
      },
      tooltip: {
        backgroundColor: darkMode ? '#0f172a' : '#ffffff',
        titleColor: darkMode ? '#f8fafc' : '#0f172a',
        bodyColor: darkMode ? '#cbd5e1' : '#334155',
        borderColor: darkMode ? '#334155' : '#cbd5e1',
        borderWidth: 1,
        callbacks: {
          label: (ctx: any) => `${ctx.dataset.label}: ${ctx.raw}%`
        }
      }
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Attribute Selector Switcher if multiple sensitive features */}
      {fairnessData.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs font-mono text-slate-400 uppercase font-semibold">Protected Attribute:</span>
          {fairnessData.map((item, idx) => (
            <button
              key={item.attribute}
              type="button"
              onClick={() => setSelectedAttrIndex(idx)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center gap-2 ${
                idx === selectedAttrIndex
                  ? 'bg-amber-500 text-slate-950 font-bold border border-amber-400'
                  : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
              }`}
            >
              <span>{item.attribute}</span>
              <span className={`w-2 h-2 rounded-full ${
                item.status === 'pass' ? 'bg-emerald-400' : item.status === 'warn' ? 'bg-amber-400' : 'bg-rose-500'
              }`} />
            </button>
          ))}
        </div>
      )}

      {/* Top Banner Status for Selected Attribute */}
      <div className={`p-5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
        currentItem.status === 'pass'
          ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200'
          : currentItem.status === 'warn'
          ? 'bg-amber-950/30 border-amber-500/30 text-amber-200'
          : 'bg-rose-950/30 border-rose-500/30 text-rose-200'
      }`}>
        <div className="flex items-start gap-3">
          {currentItem.status === 'pass' ? (
            <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
          ) : currentItem.status === 'warn' ? (
            <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
          ) : (
            <XCircle className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider">
                Fairness Assessment Verdict: {currentItem.status.toUpperCase()}
              </span>
              <span className="text-[11px] font-mono px-2 py-0.2 rounded bg-black/30 border border-current">
                Privileged Baseline: {currentItem.privileged_group}
              </span>
            </div>
            <p className="text-sm font-sans mt-1 text-slate-200">
              {currentItem.finding}
            </p>
          </div>
        </div>

        <div className="font-mono text-xs uppercase px-3 py-1.5 rounded-lg bg-black/40 border border-slate-700/80 shrink-0">
          Severity: <strong className="text-white">{currentItem.severity.toUpperCase()}</strong>
        </div>
      </div>

      {/* Key Metric Scorecards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        {/* Disparate Impact Ratio */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase flex items-center justify-between">
            <span>Disparate Impact (DI)</span>
            <span className="text-[10px] text-amber-400">EEOC 80% Rule</span>
          </div>
          <div className="font-mono text-2xl font-extrabold text-white mt-1">
            {metrics.disparate_impact_ratio}
          </div>
          <div className="text-[11px] mt-1 flex items-center gap-1 font-mono">
            <span className={metrics.disparate_impact_ratio >= 0.80 ? 'text-emerald-400' : metrics.disparate_impact_ratio >= 0.70 ? 'text-amber-400' : 'text-rose-400'}>
              {metrics.disparate_impact_ratio >= 0.80 ? '✓ Pass (≥ 0.80)' : metrics.disparate_impact_ratio >= 0.70 ? '⚠ Warn (0.70–0.80)' : '✗ Fail (< 0.70)'}
            </span>
          </div>
        </div>

        {/* Demographic Parity Difference */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase flex items-center justify-between">
            <span>Demographic Parity Diff</span>
            <span className="text-[10px] text-slate-500">Max Gap</span>
          </div>
          <div className="font-mono text-2xl font-extrabold text-white mt-1">
            {(metrics.demographic_parity_difference * 100).toFixed(1)}%
          </div>
          <div className="text-[11px] mt-1 font-mono">
            <span className={metrics.demographic_parity_difference <= 0.10 ? 'text-emerald-400' : metrics.demographic_parity_difference <= 0.20 ? 'text-amber-400' : 'text-rose-400'}>
              {metrics.demographic_parity_difference <= 0.10 ? '✓ Pass (≤ 10%)' : '⚠ Gap > 10%'}
            </span>
          </div>
        </div>

        {/* Equal Opportunity Difference */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase flex items-center justify-between">
            <span>Equal Opportunity Diff</span>
            <span className="text-[10px] text-slate-500">TPR Gap</span>
          </div>
          <div className="font-mono text-2xl font-extrabold text-white mt-1">
            {(metrics.equal_opportunity_difference * 100).toFixed(1)}%
          </div>
          <div className="text-[11px] mt-1 font-mono">
            <span className={metrics.equal_opportunity_difference <= 0.10 ? 'text-emerald-400' : 'text-amber-400'}>
              {metrics.equal_opportunity_difference <= 0.10 ? '✓ Pass (≤ 10%)' : '⚠ Caution > 10%'}
            </span>
          </div>
        </div>

        {/* Equalized Odds Gap */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase flex items-center justify-between">
            <span>Equalized Odds Gap</span>
            <span className="text-[10px] text-slate-500">Max(TPR, FPR)</span>
          </div>
          <div className="font-mono text-2xl font-extrabold text-white mt-1">
            {(metrics.equalized_odds_gap * 100).toFixed(1)}%
          </div>
          <div className="text-[11px] mt-1 text-slate-400 font-mono">
            Worst FPR Gap: {(metrics.worst_fpr_gap * 100).toFixed(1)}%
          </div>
        </div>

      </div>

      {/* Bar Chart: Selection Rates per Group with 80% Rule Line */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-4">
          <div>
            <h4 className="font-display font-bold text-white text-base">
              Selection Rates vs. EEOC 80% Rule Threshold
            </h4>
            <p className="text-xs text-slate-400">
              Red dashed line represents four-fifths (80%) of the privileged group's positive selection rate.
            </p>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded bg-slate-950 border border-slate-800 text-slate-300">
            Attribute: <strong>{currentItem.attribute}</strong>
          </span>
        </div>

        <div className="w-full h-72 sm:h-80">
          {/* @ts-ignore */}
          <Bar data={barChartData} options={barChartOptions} />
        </div>
      </div>

      {/* Subgroup Error Rates Table (FPR, FNR, TPR, Sample Size) */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md">
        <h4 className="font-display font-bold text-white text-base mb-3">
          Subgroup Performance & Error Rate Breakdown
        </h4>

        {small_group_warnings && small_group_warnings.length > 0 && (
          <div className="mb-4 p-3 rounded-lg bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs flex items-center gap-2 font-mono">
            <Info size={15} className="shrink-0 text-amber-400" />
            <span>
              Small subgroup sample warning: {small_group_warnings.map(w => `${w.group} (N=${w.size})`).join(', ')} have fewer than 30 observations. Metrics may carry high statistical variance.
            </span>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[11px]">
                <th className="py-2.5 px-3">Subgroup</th>
                <th className="py-2.5 px-3">Sample (N)</th>
                <th className="py-2.5 px-3">Selection Rate</th>
                <th className="py-2.5 px-3">True Pos (TPR)</th>
                <th className="py-2.5 px-3">False Pos (FPR)</th>
                <th className="py-2.5 px-3">False Neg (FNR)</th>
                <th className="py-2.5 px-3">DI vs Baseline</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-200">
              {Object.entries(subgroup_breakdown).map(([groupName, stats]) => {
                const isPriv = groupName === currentItem.privileged_group;
                const diVal = currentItem.di_per_subgroup[groupName] || (isPriv ? 1.0 : 0.0);
                return (
                  <tr key={groupName} className={isPriv ? 'bg-amber-500/5' : ''}>
                    <td className="py-2.5 px-3 font-semibold text-white flex items-center gap-1.5">
                      {groupName}
                      {isPriv && (
                        <span className="text-[9px] px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded">
                          Privileged Baseline
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{stats.size}</td>
                    <td className="py-2.5 px-3 font-bold text-white">{(stats.selection_rate * 100).toFixed(1)}%</td>
                    <td className="py-2.5 px-3 text-emerald-400">{(stats.tpr * 100).toFixed(1)}%</td>
                    <td className="py-2.5 px-3 text-rose-400">{(stats.fpr * 100).toFixed(1)}%</td>
                    <td className="py-2.5 px-3 text-amber-400">{(stats.fnr * 100).toFixed(1)}%</td>
                    <td className="py-2.5 px-3 font-bold">
                      {isPriv ? (
                        <span className="text-slate-500">1.00 (Base)</span>
                      ) : (
                        <span className={diVal >= 0.80 ? 'text-emerald-400' : diVal >= 0.70 ? 'text-amber-400' : 'text-rose-400'}>
                          {diVal.toFixed(3)}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reviewer Notes & Limitations */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-slate-400">
        <h5 className="font-mono uppercase font-bold text-slate-300 mb-1 flex items-center gap-1.5">
          <Info size={14} className="text-amber-400" /> Reviewer Notes & Fair Lending Limitations:
        </h5>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Passing the 80% rule on sample data does not immunize deployers from disparate impact liability under EEOC Uniform Guidelines if underlying historical labels embody societal bias.
          </li>
          <li>
            Continuous sensitive attributes (such as applicant age) are segmented into discrete brackets (<code className="text-amber-300">&lt;25</code>, <code className="text-amber-300">25–60</code>, <code className="text-amber-300">&gt;60</code>) to expose generational disparate treatment.
          </li>
        </ul>
      </div>

    </div>
  );
};
