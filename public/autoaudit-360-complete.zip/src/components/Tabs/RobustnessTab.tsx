import React from 'react';
import { RobustnessAudit } from '../../types';
import { AlertTriangle, CheckCircle, Info, ShieldAlert, ShieldCheck, Zap, XCircle } from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

interface RobustnessTabProps {
  robustnessData: RobustnessAudit;
  darkMode?: boolean;
}

export const RobustnessTab: React.FC<RobustnessTabProps> = ({ robustnessData, darkMode = true }) => {
  if (!robustnessData) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
        No Robustness audit data available.
      </div>
    );
  }

  const {
    status,
    severity,
    finding,
    baseline_metrics,
    metric_drop_10pct,
    prediction_flip_rate_5pct,
    fairness_stability_delta,
    label_flip_tests,
    perturbation_tests,
    chart_data
  } = robustnessData;

  // Line Chart for Label Flip Degradation
  const lineData = {
    labels: chart_data.label_flips.x_labels,
    datasets: [
      {
        label: 'Accuracy',
        data: chart_data.label_flips.accuracy,
        borderColor: '#10B981',
        backgroundColor: 'rgba(16, 185, 129, 0.2)',
        tension: 0.2,
        pointRadius: 4,
      },
      {
        label: 'F1-Score',
        data: chart_data.label_flips.f1,
        borderColor: '#06B6D4',
        backgroundColor: 'rgba(6, 182, 212, 0.2)',
        tension: 0.2,
        pointRadius: 4,
      },
      {
        label: 'ROC-AUC',
        data: chart_data.label_flips.roc_auc,
        borderColor: '#E5A93C',
        backgroundColor: 'rgba(229, 169, 60, 0.2)',
        tension: 0.2,
        pointRadius: 4,
      }
    ]
  };

  const lineOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: false,
        min: 0.4,
        max: 1.0,
        ticks: {
          callback: (val: any) => `${(val * 100).toFixed(0)}%`,
          color: darkMode ? '#94a3b8' : '#64748b',
          font: { family: "'JetBrains Mono', monospace", size: 10 }
        },
        grid: {
          color: darkMode ? 'rgba(148, 163, 184, 0.1)' : 'rgba(0, 0, 0, 0.06)'
        }
      },
      x: {
        ticks: {
          color: darkMode ? '#cbd5e1' : '#334155',
          font: { family: "'Space Grotesk', system-ui", size: 11, weight: 600 as const }
        },
        grid: { display: false }
      }
    },
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: darkMode ? '#e2e8f0' : '#1e293b',
          font: { family: "'Plus Jakarta Sans', system-ui", size: 11 }
        }
      },
      tooltip: {
        backgroundColor: darkMode ? '#0f172a' : '#ffffff',
        titleColor: darkMode ? '#f8fafc' : '#0f172a',
        bodyColor: darkMode ? '#cbd5e1' : '#334155',
        borderColor: darkMode ? '#334155' : '#cbd5e1',
        borderWidth: 1,
        callbacks: {
          label: (ctx: any) => `${ctx.dataset.label}: ${(ctx.raw * 100).toFixed(1)}%`
        }
      }
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner Status */}
      <div className={`p-5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
        status === 'pass'
          ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200'
          : status === 'warn'
          ? 'bg-amber-950/30 border-amber-500/30 text-amber-200'
          : 'bg-rose-950/30 border-rose-500/30 text-rose-200'
      }`}>
        <div className="flex items-start gap-3">
          {status === 'pass' ? (
            <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
          ) : status === 'warn' ? (
            <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
          ) : (
            <XCircle className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider">
                Adversarial & Perturbation Resilience: {status.toUpperCase()}
              </span>
              <span className="text-[11px] font-mono px-2 py-0.2 rounded bg-black/30 border border-current">
                Stress Limit: 20% Label Flip / 10% Gaussian Noise
              </span>
            </div>
            <p className="text-sm font-sans mt-1 text-slate-200">
              {finding}
            </p>
          </div>
        </div>

        <div className="font-mono text-xs uppercase px-3 py-1.5 rounded-lg bg-black/40 border border-slate-700/80 shrink-0">
          Severity: <strong className="text-white">{severity.toUpperCase()}</strong>
        </div>
      </div>

      {/* 3 Pillar Scorecards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* Metric Drop at 10% Flips */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase flex items-center justify-between">
            <span>10% Label Poisoning Drop</span>
            <span className="text-[10px] text-amber-400">Tolerance &le; 5%</span>
          </div>
          <div className="font-mono text-2xl font-extrabold text-white mt-1">
            {(metric_drop_10pct * 100).toFixed(1)}%
          </div>
          <div className="text-[11px] mt-1 font-mono">
            <span className={metric_drop_10pct <= 0.05 ? 'text-emerald-400' : metric_drop_10pct <= 0.12 ? 'text-amber-400' : 'text-rose-400'}>
              {metric_drop_10pct <= 0.05 ? '✓ Pass (≤ 5% drop)' : metric_drop_10pct <= 0.12 ? '⚠ Warning (5%–12%)' : '✗ Severe degradation (>12%)'}
            </span>
          </div>
        </div>

        {/* Prediction Flip Rate at 5% Noise */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase flex items-center justify-between">
            <span>5% Feature Noise Flip Rate</span>
            <span className="text-[10px] text-cyan-400">Boundary Jitter</span>
          </div>
          <div className="font-mono text-2xl font-extrabold text-white mt-1">
            {(prediction_flip_rate_5pct * 100).toFixed(1)}%
          </div>
          <div className="text-[11px] mt-1 font-mono text-slate-400">
            Inference shifts under 5% std Gaussian noise
          </div>
        </div>

        {/* Fairness Stability Delta */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase flex items-center justify-between">
            <span>Fairness Drift (&Delta; DI)</span>
            <span className="text-[10px] text-slate-500">Stability</span>
          </div>
          <div className="font-mono text-2xl font-extrabold text-white mt-1">
            &Delta; {fairness_stability_delta.toFixed(3)}
          </div>
          <div className="text-[11px] mt-1 font-mono">
            <span className={fairness_stability_delta <= 0.08 ? 'text-emerald-400' : 'text-amber-400'}>
              {fairness_stability_delta <= 0.08 ? '✓ Stable (≤ 0.08 shift)' : '⚠ Disparate Impact shifts'}
            </span>
          </div>
        </div>

      </div>

      {/* Line Chart: Metric Drops under Label Flips */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-4">
          <div>
            <h4 className="font-display font-bold text-white text-base">
              Label Corruption Sensitivity Curve (0% &rarr; 5% &rarr; 10% &rarr; 20%)
            </h4>
            <p className="text-xs text-slate-400">
              Assesses how rapidly classification accuracy, F1-score, and ROC-AUC decay when training targets are corrupted.
            </p>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded bg-slate-950 border border-slate-800 text-slate-300">
            Baseline Accuracy: {(baseline_metrics.accuracy * 100).toFixed(1)}%
          </span>
        </div>

        <div className="w-full h-72 sm:h-80">
          {/* @ts-ignore */}
          <Line data={lineData} options={lineOptions} />
        </div>
      </div>

      {/* Perturbation Stress Testing Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md">
        <h4 className="font-display font-bold text-white text-base mb-3">
          Feature Noise Injection & Disparate Impact Stability
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[11px]">
                <th className="py-2.5 px-3">Perturbation Level</th>
                <th className="py-2.5 px-3">Prediction Flip Rate</th>
                <th className="py-2.5 px-3">Stressed Accuracy</th>
                <th className="py-2.5 px-3">Accuracy Drop</th>
                <th className="py-2.5 px-3">Perturbed DI Ratio</th>
                <th className="py-2.5 px-3">Fairness Shift (&Delta; DI)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-200">
              {perturbation_tests.map(test => (
                <tr key={test.noise_level_pct}>
                  <td className="py-2.5 px-3 font-bold text-white">{test.noise_level_pct}% Std Noise</td>
                  <td className="py-2.5 px-3 text-cyan-400 font-semibold">{(test.prediction_flip_rate * 100).toFixed(1)}%</td>
                  <td className="py-2.5 px-3">{(test.accuracy * 100).toFixed(1)}%</td>
                  <td className="py-2.5 px-3 text-amber-400 font-semibold">{(test.accuracy_drop * 100).toFixed(1)}%</td>
                  <td className="py-2.5 px-3 text-white font-bold">{test.disparate_impact.toFixed(3)}</td>
                  <td className="py-2.5 px-3">
                    <span className={test.di_delta <= 0.08 ? 'text-emerald-400' : 'text-amber-400'}>
                      {test.di_delta.toFixed(3)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reviewer Notes & Limitations */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-slate-400">
        <h5 className="font-mono uppercase font-bold text-slate-300 mb-1 flex items-center gap-1.5">
          <Info size={14} className="text-amber-400" /> Reviewer Notes & Adversarial Bounds:
        </h5>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Models maintaining &le; 5% metric drop under 10% synthetic label flips exhibit high inductive margin against mislabeled ground-truth records.
          </li>
          <li>
            Fairness stability tracks whether slight data jitter pushes vulnerable marginal applicants below the decision boundary disproportionately.
          </li>
        </ul>
      </div>

    </div>
  );
};
