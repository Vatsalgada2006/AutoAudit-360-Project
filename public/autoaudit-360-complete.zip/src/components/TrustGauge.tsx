import React, { useEffect, useState } from 'react';
import { ShieldCheck, AlertCircle, XCircle } from 'lucide-react';
import { AuditScores } from '../types';

interface TrustGaugeProps {
  scores: AuditScores;
}

export const TrustGauge: React.FC<TrustGaugeProps> = ({ scores }) => {
  const [displayScore, setDisplayScore] = useState(0);

  useEffect(() => {
    let start = 0;
    const target = scores.overall_trust_score;
    const duration = 1000;
    const steps = 30;
    const increment = target / steps;
    const intervalTime = duration / steps;

    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setDisplayScore(target);
        clearInterval(timer);
      } else {
        setDisplayScore(Math.round(start * 10) / 10);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [scores.overall_trust_score]);

  const { rag_status } = scores;
  const strokeDashoffset = 440 - (440 * (displayScore / 100));

  const stampColorClass =
    rag_status === 'green'
      ? 'stamp-pass'
      : rag_status === 'amber'
      ? 'stamp-warn'
      : 'stamp-fail';

  const stampText =
    rag_status === 'green'
      ? 'CERTIFIED TRUSTWORTHY - PASS'
      : rag_status === 'amber'
      ? 'CONDITIONAL - REVIEW'
      : 'NON-COMPLIANT - FAIL';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-lg">
      
      {/* Left: Circular Dial */}
      <div className="flex items-center gap-6">
        <div className="relative w-32 h-32 flex items-center justify-center shrink-0">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
            {/* Background Circle */}
            <circle
              cx="80"
              cy="80"
              r="70"
              className="text-slate-800"
              strokeWidth="12"
              stroke="currentColor"
              fill="transparent"
            />
            {/* Progress Arc */}
            <circle
              cx="80"
              cy="80"
              r="70"
              className={
                rag_status === 'green'
                  ? 'text-emerald-500'
                  : rag_status === 'amber'
                  ? 'text-amber-500'
                  : 'text-rose-500'
              }
              strokeWidth="12"
              strokeDasharray={440}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
              style={{ transition: 'stroke-dashoffset 1s ease-out' }}
            />
          </svg>

          {/* Inner Score Label */}
          <div className="absolute flex flex-col items-center justify-center">
            <span className="font-mono text-3xl font-extrabold text-white">
              {displayScore}
            </span>
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
              / 100 Index
            </span>
          </div>
        </div>

        {/* Text Verdict */}
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-mono font-semibold uppercase text-slate-400">
              Trust & Regulatory Assurance Status:
            </span>
          </div>

          {/* Signature Custom Stamped Badge */}
          <div className={`stamp-badge ${stampColorClass} mb-2 text-sm sm:text-base`}>
            {stampText}
          </div>

          <p className="text-xs text-slate-300 max-w-sm">
            {rag_status === 'green'
              ? 'Model complies with baseline four-fifths fairness, SHAP attribution, and statutory risk governance thresholds.'
              : rag_status === 'amber'
              ? 'Conditional rating: Disparities or documentation gaps detected. Requires manual supervisory mitigation.'
              : 'Critical deficiencies in algorithmic fairness or statutory safeguards. Remediation mandatory before deployment.'}
          </p>
        </div>
      </div>

      {/* Right: Dimension Quick Breakdown */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 w-full sm:w-auto">
        {Object.entries(scores.dimension_scores).map(([axis, val]) => (
          <div key={axis} className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-lg text-center">
            <div className="text-[10px] font-mono text-slate-400 uppercase truncate" title={axis}>
              {axis.replace(' Readiness', '').replace(' Completeness', '')}
            </div>
            <div className={`font-mono text-sm font-bold mt-0.5 ${
              val >= 75 ? 'text-emerald-400' : val >= 50 ? 'text-amber-400' : 'text-rose-400'
            }`}>
              {val}
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
