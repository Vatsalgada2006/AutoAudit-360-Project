import React, { useEffect, useState } from 'react';
import { Shield, CheckCircle2, Loader2, Sparkles, AlertTriangle } from 'lucide-react';

interface ScannerHeroProps {
  currentStage: number;
  totalStages: number;
  stageName: string;
}

const STAGES = [
  "Ingesting Dataset & Generating SHA-256 Cryptographic Hash...",
  "Executing Fairness Battery: Demographic Parity & EEOC 80% Rule...",
  "Computing Global SHAP Explanations & Detecting Proxy Leakage...",
  "Injecting Adversarial Perturbations & Synthetic Label Flips...",
  "Evaluating EU AI Act (Annex III) & India DPDP Act 2023 Readiness...",
  "Synthesizing Production AI Model Card & Trust Radar Index..."
];

export const ScannerHero: React.FC<ScannerHeroProps> = ({ currentStage }) => {
  const [dots, setDots] = useState('');

  useEffect(() => {
    const timer = setInterval(() => {
      setDots(prev => (prev.length >= 3 ? '' : prev + '.'));
    }, 400);
    return () => clearInterval(timer);
  }, []);

  const progress = Math.min(100, Math.round(((currentStage + 1) / STAGES.length) * 100));

  return (
    <div className="relative overflow-hidden rounded-xl border border-amber-500/30 bg-slate-900/90 p-6 md:p-8 shadow-2xl shadow-amber-500/10 mb-8 backdrop-blur-md">
      
      {/* Laser Scanning Line */}
      <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee] animate-scanner pointer-events-none" />

      {/* Grid background effect */}
      <div className="absolute inset-0 bg-radar-grid opacity-30 pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
        
        {/* Left: Reticle & Title */}
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl bg-amber-500/10 border border-amber-500/40 flex items-center justify-center relative shadow-inner">
            <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
            <div className="absolute inset-2 border border-cyan-400/30 rounded-lg animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono font-bold uppercase tracking-widest text-amber-400 px-2 py-0.5 rounded bg-amber-400/10 border border-amber-400/20">
                FORENSIC REGULATORY SCANNER ACTIVE
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold font-display text-white mt-1">
              Executing Battery of Trustworthy AI Audits{dots}
            </h2>
            <p className="text-sm font-mono text-cyan-300 mt-0.5">
              Current Stage [{currentStage + 1}/{STAGES.length}]: {STAGES[currentStage] || STAGES[0]}
            </p>
          </div>
        </div>

        {/* Right: Progress Meter */}
        <div className="w-full md:w-64 bg-slate-950/80 p-4 rounded-lg border border-slate-800">
          <div className="flex justify-between items-center text-xs font-mono mb-2">
            <span className="text-slate-400 uppercase">Verification Progress</span>
            <span className="text-amber-400 font-bold">{progress}%</span>
          </div>

          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-cyan-400 rounded-full transition-all duration-300 ease-out shadow-[0_0_8px_#38bdf8]"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="flex items-center justify-between mt-2.5 text-[10px] font-mono text-slate-500">
            <span>ISOLATED SANDBOX</span>
            <span className="text-cyan-400">DETERMINISTIC SEED: 42</span>
          </div>
        </div>

      </div>

      {/* Audit Step Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 mt-6 pt-5 border-t border-slate-800/80">
        {STAGES.map((stg, idx) => {
          const isDone = idx < currentStage;
          const isCurrent = idx === currentStage;
          return (
            <div
              key={idx}
              className={`p-2 rounded text-[11px] font-mono flex items-center gap-1.5 transition-all ${
                isDone
                  ? 'bg-emerald-950/40 border border-emerald-500/30 text-emerald-300'
                  : isCurrent
                  ? 'bg-amber-950/50 border border-amber-500/50 text-amber-200 animate-pulse'
                  : 'bg-slate-950/40 border border-slate-800 text-slate-500'
              }`}
            >
              {isDone ? (
                <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
              ) : isCurrent ? (
                <Loader2 size={13} className="text-amber-400 animate-spin shrink-0" />
              ) : (
                <div className="w-2.5 h-2.5 rounded-full border border-slate-600 shrink-0" />
              )}
              <span className="truncate">Step 0{idx + 1}</span>
            </div>
          );
        })}
      </div>

    </div>
  );
};
