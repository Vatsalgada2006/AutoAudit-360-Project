import React, { useEffect, useRef } from 'react';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
  ChartData
} from 'chart.js';
import { Radar } from 'react-chartjs-2';
import { AuditScores } from '../types';

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

interface RadarChartProps {
  scores: AuditScores;
  darkMode?: boolean;
}

export const RadarChart: React.FC<RadarChartProps> = ({ scores, darkMode = true }) => {
  const chartRef = useRef<any>(null);

  const axes = [
    'Fairness',
    'Explainability',
    'Robustness',
    'EU AI Act Readiness',
    'DPDP Act 2023 Readiness',
    'Documentation Completeness'
  ];

  const values = axes.map(a => scores.dimension_scores[a as keyof typeof scores.dimension_scores] || 0);
  const benchmarkValues = [75, 75, 75, 75, 75, 75];

  const data: ChartData<'radar'> = {
    labels: axes,
    datasets: [
      {
        label: 'Model Trust Profile',
        data: values,
        backgroundColor: 'rgba(229, 169, 60, 0.25)', // Regulatory Amber fill
        borderColor: '#E5A93C', // Regulatory Amber border
        borderWidth: 2.5,
        pointBackgroundColor: '#F59E0B',
        pointBorderColor: '#ffffff',
        pointHoverBackgroundColor: '#ffffff',
        pointHoverBorderColor: '#F59E0B',
        pointRadius: 4.5,
      },
      {
        label: 'Minimum Compliance Benchmark (75.0)',
        data: benchmarkValues,
        backgroundColor: 'rgba(6, 182, 212, 0.05)',
        borderColor: 'rgba(6, 182, 212, 0.7)',
        borderWidth: 1.5,
        borderDash: [4, 4],
        pointRadius: 2,
        pointBackgroundColor: 'rgba(6, 182, 212, 0.8)',
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      r: {
        angleLines: {
          color: darkMode ? 'rgba(148, 163, 184, 0.15)' : 'rgba(0, 0, 0, 0.1)',
        },
        grid: {
          color: darkMode ? 'rgba(148, 163, 184, 0.15)' : 'rgba(0, 0, 0, 0.08)',
        },
        pointLabels: {
          color: darkMode ? '#cbd5e1' : '#334155',
          font: {
            family: "'Space Grotesk', system-ui, sans-serif",
            size: 11,
            weight: 600 as const,
          },
        },
        ticks: {
          display: true,
          stepSize: 20,
          backdropColor: 'transparent',
          color: darkMode ? '#64748b' : '#94a3b8',
          font: {
            family: "'JetBrains Mono', monospace",
            size: 9,
          },
        },
        suggestedMin: 0,
        suggestedMax: 100,
      },
    },
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: darkMode ? '#e2e8f0' : '#1e293b',
          font: {
            family: "'Plus Jakarta Sans', system-ui, sans-serif",
            size: 11,
          },
          padding: 16,
        },
      },
      tooltip: {
        backgroundColor: darkMode ? '#0f172a' : '#ffffff',
        titleColor: darkMode ? '#f8fafc' : '#0f172a',
        bodyColor: darkMode ? '#cbd5e1' : '#334155',
        borderColor: darkMode ? '#334155' : '#cbd5e1',
        borderWidth: 1,
        padding: 10,
        callbacks: {
          label: (context: any) => `${context.dataset.label}: ${context.raw} / 100`
        }
      }
    },
  };

  return (
    <div className="w-full h-80 sm:h-96 relative">
      {/* @ts-ignore */}
      <Radar ref={chartRef} data={data} options={options} />
    </div>
  );
};
