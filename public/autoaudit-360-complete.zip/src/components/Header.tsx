import React from 'react';
import { ShieldCheck, Sun, Moon, Cpu, PlayCircle, Activity } from 'lucide-react';

interface HeaderProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onRunDemo: (name: 'german_credit' | 'compas') => void;
  isAuditing: boolean;
  overallScore?: number;
  ragStatus?: 'green' | 'amber' | 'red';
}

export const Header: React.FC<HeaderProps> = ({
  darkMode,
  setDarkMode,
  onRunDemo,
  isAuditing,
  overallScore,
  ragStatus
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40 px-4 lg:px-8 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Brand & Logo */}
        <div className="flex items-center gap-3.5 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-3">
            {/* Custom Inline SVG Logo: Regulatory Shield Reticle */}
            <div className="relative w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500/20 to-cyan-500/10 border border-amber-500/30 flex items-center justify-center p-2 shadow-inner">
              <svg viewBox="0 0 40 40" className="w-full h-full text-amber-400" fill="none" stroke="currentColor" strokeWidth="2.2">
                <circle cx="20" cy="20" r="16" strokeDasharray="3 3" opacity="0.4" />
                <path d="M20 4L32 9V20C32 27.5 26.8 33.8 20 36C13.2 33.8 8 27.5 8 20V9L20 4Z" stroke="currentColor" />
                <circle cx="20" cy="20" r="4" fill="currentColor" fillOpacity="0.3" stroke="currentColor" />
                <path d="M20 12V16M20 24V28M12 20H16M24 20H28" strokeLinecap="round" />
              </svg>
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-cyan-400 rounded-full animate-ping opacity-75" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
                  AutoAudit<span className="text-amber-400">-360</span>
                </h1>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-amber-400/10 text-amber-300 border border-amber-400/20 font-semibold">
                  v1.0 Compliance Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 font-sans hidden sm:block">
                Trustworthy AI Audit Suite &bull; EU AI Act &bull; India DPDP Act 2023
              </p>
            </div>
          </div>

          {/* Mobile Dark Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="md:hidden p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            aria-label="Toggle theme"
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>

        {/* Center / Action Bar */}
        <div className="flex flex-wrap items-center gap-2.5 justify-center md:justify-end w-full md:w-auto">
          {/* Quick Demo Buttons */}
          <div className="flex items-center gap-2 bg-slate-950/70 p-1 rounded-lg border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 px-2 uppercase font-medium">1-Click Demos:</span>
            
            <button
              onClick={() => onRunDemo('german_credit')}
              disabled={isAuditing}
              className="text-xs font-medium px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-amber-200 border border-slate-700 flex items-center gap-1.5 transition-all disabled:opacity-50"
              title="Audit German Credit Risk Dataset"
            >
              <PlayCircle size={14} className="text-amber-400" />
              German Credit
            </button>

            <button
              onClick={() => onRunDemo('compas')}
              disabled={isAuditing}
              className="text-xs font-medium px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-cyan-200 border border-slate-700 flex items-center gap-1.5 transition-all disabled:opacity-50"
              title="Audit ProPublica COMPAS Recidivism Dataset"
            >
              <Activity size={14} className="text-cyan-400" />
              COMPAS Recidivism
            </button>
          </div>

          {/* RAG Status Pill if available */}
          {overallScore !== undefined && ragStatus && (
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono font-bold uppercase ${
              ragStatus === 'green'
                ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-300'
                : ragStatus === 'amber'
                ? 'bg-amber-950/50 border-amber-500/40 text-amber-300'
                : 'bg-rose-950/50 border-rose-500/40 text-rose-300'
            }`}>
              <span className={`w-2 h-2 rounded-full ${
                ragStatus === 'green' ? 'bg-emerald-400 animate-pulse' : ragStatus === 'amber' ? 'bg-amber-400' : 'bg-rose-400'
              }`} />
              Score: {overallScore}/100 ({ragStatus})
            </div>
          )}

          {/* Desktop Light/Dark Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="hidden md:flex p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
            aria-label="Toggle theme"
            title="Toggle Light / Dark mode"
          >
            {darkMode ? <Sun size={17} className="text-amber-400" /> : <Moon size={17} className="text-slate-300" />}
          </button>
        </div>

      </div>
    </header>
  );
};
