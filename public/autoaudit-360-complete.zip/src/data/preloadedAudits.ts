import { FullAuditResult } from '../types';

export const GERMAN_CREDIT_AUDIT: FullAuditResult = {
  "meta": {
    "audit_id": "c18b9a36",
    "timestamp": "2026-10-27 19:47:47 UTC",
    "model_name": "Model_c18b9a36",
    "algorithm": "RandomForestClassifier (Auto-trained production baseline)",
    "is_default_trained": true,
    "framework": "scikit-learn",
    "random_seed": 42,
    "dataset_hash": "b131337be558d082ca5a949b914123b520620677ada79e5c7f1526d45f376ed0",
    "author": {
      "name": "VATSAL GADA",
      "prn": "124BTAI1005",
      "roll_no": "12",
      "class": "TY-AIDS",
      "institution": "SAKEC",
      "project": "AutoAudit-360: End-to-End Trustworthy AI Audit & Regulatory Compliance Suite"
    }
  },
  "data_summary": {
    "total_rows": 1000,
    "total_features": 11,
    "target_column": "Creditability",
    "positive_label": "1",
    "positive_rate": 46.2,
    "sensitive_attributes": [
      "Sex",
      "Age"
    ],
    "missing_percentage": 0.0
  },
  "performance": {
    "accuracy": 0.62,
    "balanced_accuracy": 0.6087,
    "precision": 0.6143,
    "recall": 0.4674,
    "f1_score": 0.5309,
    "roc_auc": 0.6695
  },
  "fairness": [
    {
      "attribute": "Sex",
      "privileged_group": "Male",
      "status": "warn",
      "severity": "medium",
      "finding": "Disparate Impact (0.77) is in warning band [0.70, 0.80).",
      "metrics": {
        "disparate_impact_ratio": 0.7729,
        "demographic_parity_difference": 0.0967,
        "equal_opportunity_difference": 0.0422,
        "equalized_odds_gap": 0.0497,
        "worst_fpr_gap": 0.0497
      },
      "subgroup_breakdown": {
        "Female": {
          "size": 319,
          "selection_rate": 0.3292,
          "tpr": 0.7252,
          "fpr": 0.0532,
          "fnr": 0.2748,
          "tnr": 0.9468,
          "tp": 95,
          "fp": 10,
          "fn": 36,
          "tn": 178
        },
        "Male": {
          "size": 681,
          "selection_rate": 0.4258,
          "tpr": 0.7674,
          "fpr": 0.1029,
          "fnr": 0.2326,
          "tnr": 0.8971,
          "tp": 254,
          "fp": 36,
          "fn": 77,
          "tn": 314
        }
      },
      "di_per_subgroup": {
        "Female": 0.7729
      },
      "small_group_warnings": [],
      "chart_data": {
        "labels": [
          "Female",
          "Male"
        ],
        "selection_rates_pct": [
          32.92,
          42.58
        ],
        "eighty_percent_line_pct": 34.07,
        "privileged_rate_pct": 42.58
      }
    },
    {
      "attribute": "Age",
      "privileged_group": "Senior (>60)",
      "status": "fail",
      "severity": "high",
      "finding": "Disparate Impact (0.21) violates EEOC 80% rule (<0.7). Demographic Parity Difference (57.46%) exceeds 20% tolerance. Equal Opportunity Difference (49.90%) indicates significant recall disparity.",
      "metrics": {
        "disparate_impact_ratio": 0.21,
        "demographic_parity_difference": 0.5746,
        "equal_opportunity_difference": 0.499,
        "equalized_odds_gap": 0.499,
        "worst_fpr_gap": 0.3261
      },
      "subgroup_breakdown": {
        "Prime (25-60)": {
          "size": 665,
          "selection_rate": 0.403,
          "tpr": 0.7745,
          "fpr": 0.0864,
          "fnr": 0.2255,
          "tnr": 0.9136,
          "tp": 237,
          "fp": 31,
          "fn": 69,
          "tn": 328
        },
        "Senior (>60)": {
          "size": 132,
          "selection_rate": 0.7273,
          "tpr": 0.9419,
          "fpr": 0.3261,
          "fnr": 0.0581,
          "tnr": 0.6739,
          "tp": 81,
          "fp": 15,
          "fn": 5,
          "tn": 31
        },
        "Young (<25)": {
          "size": 203,
          "selection_rate": 0.1527,
          "tpr": 0.4429,
          "fpr": 0.0,
          "fnr": 0.5571,
          "tnr": 1.0,
          "tp": 31,
          "fp": 0,
          "fn": 39,
          "tn": 133
        }
      },
      "di_per_subgroup": {
        "Prime (25-60)": 0.5541,
        "Young (<25)": 0.21
      },
      "small_group_warnings": [],
      "chart_data": {
        "labels": [
          "Prime (25-60)",
          "Senior (>60)",
          "Young (<25)"
        ],
        "selection_rates_pct": [
          40.3,
          72.73,
          15.27
        ],
        "eighty_percent_line_pct": 58.18,
        "privileged_rate_pct": 72.73
      }
    }
  ],
  "explain": {
    "status": "warn",
    "severity": "medium",
    "explainer_type": "TreeExplainer",
    "shap_success": true,
    "finding": "Moderate Risk: 1 sensitive attribute or proxy variable detected in top 5 features. Protected features in top 5: num__Age. Causality Disclaimer: SHAP values quantify predictive attribution within the mathematical manifold, not causal mechanisms.",
    "disclaimer": "SHAP feature importances reflect marginal predictive contribution to the model's scoring manifold. They do NOT establish legal or real-world causality.",
    "top_features": [
      {
        "feature": "num__Age",
        "importance": 0.0594,
        "is_sensitive": true,
        "is_proxy": false
      },
      {
        "feature": "num__Credit_Amount",
        "importance": 0.0465,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__Account_Status_No checking",
        "importance": 0.0194,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__Credit_History_Existing paid",
        "importance": 0.0141,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__Savings_Account_<100 DM",
        "importance": 0.0134,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "num__Duration_Months",
        "importance": 0.0123,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__Sex_Male",
        "importance": 0.0109,
        "is_sensitive": true,
        "is_proxy": false
      },
      {
        "feature": "cat__Account_Status_<0 DM",
        "importance": 0.0105,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__Housing_Rent",
        "importance": 0.0102,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__Sex_Female",
        "importance": 0.0087,
        "is_sensitive": true,
        "is_proxy": false
      }
    ],
    "sensitive_in_top_5": [
      "num__Age"
    ],
    "proxies_in_top_5": [],
    "flagged_count": 1,
    "chart_data": {
      "labels": [
        "num__Age",
        "num__Credit_Amount",
        "cat__Account_Status_No checking",
        "cat__Credit_History_Existing paid",
        "cat__Savings_Account_<100 DM",
        "num__Duration_Months",
        "cat__Sex_Male",
        "cat__Account_Status_<0 DM",
        "cat__Housing_Rent",
        "cat__Sex_Female"
      ],
      "values": [
        0.0594,
        0.0465,
        0.0194,
        0.0141,
        0.0134,
        0.0123,
        0.0109,
        0.0105,
        0.0102,
        0.0087
      ]
    }
  },
  "robustness": {
    "status": "pass",
    "severity": "none",
    "finding": "Model exhibits high robustness: metric drop at 10% label flips is 0.4% (<=5% pass threshold). Inferences remain steady under perturbation. Fairness instability alert: Disparate Impact drifts by 0.21 under input perturbation.",
    "baseline_metrics": {
      "accuracy": 0.62,
      "f1": 0.5309,
      "roc_auc": 0.6695
    },
    "metric_drop_10pct": 0.004,
    "prediction_flip_rate_5pct": 0.07,
    "fairness_stability_delta": 0.2073,
    "label_flip_tests": [
      {
        "flip_rate_pct": 5,
        "accuracy": 0.6,
        "f1": 0.5062,
        "roc_auc": 0.6445,
        "accuracy_drop": 0.02,
        "f1_drop": 0.0247,
        "roc_auc_drop": 0.025,
        "relative_metric_drop": 0.0224
      },
      {
        "flip_rate_pct": 10,
        "accuracy": 0.605,
        "f1": 0.538,
        "roc_auc": 0.6559,
        "accuracy_drop": 0.015,
        "f1_drop": 0.0,
        "roc_auc_drop": 0.0136,
        "relative_metric_drop": 0.004
      },
      {
        "flip_rate_pct": 20,
        "accuracy": 0.57,
        "f1": 0.5743,
        "roc_auc": 0.6348,
        "accuracy_drop": 0.05,
        "f1_drop": 0.0,
        "roc_auc_drop": 0.0347,
        "relative_metric_drop": 0.0033
      }
    ],
    "perturbation_tests": [
      {
        "noise_level_pct": 1,
        "prediction_flip_rate": 0.01,
        "accuracy": 0.63,
        "accuracy_drop": 0.0,
        "disparate_impact": 0.7456,
        "di_delta": 0.0833
      },
      {
        "noise_level_pct": 5,
        "prediction_flip_rate": 0.07,
        "accuracy": 0.6,
        "accuracy_drop": 0.02,
        "disparate_impact": 0.8696,
        "di_delta": 0.2073
      },
      {
        "noise_level_pct": 10,
        "prediction_flip_rate": 0.085,
        "accuracy": 0.615,
        "accuracy_drop": 0.005,
        "disparate_impact": 0.7,
        "di_delta": 0.0377
      }
    ],
    "chart_data": {
      "label_flips": {
        "x_labels": [
          "0%",
          "5%",
          "10%",
          "20%"
        ],
        "accuracy": [
          0.62,
          0.6,
          0.605,
          0.57
        ],
        "f1": [
          0.5309,
          0.5062,
          0.538,
          0.5743
        ],
        "roc_auc": [
          0.6695,
          0.6445,
          0.6559,
          0.6348
        ]
      },
      "perturbation": {
        "x_labels": [
          "1% Noise",
          "5% Noise",
          "10% Noise"
        ],
        "flip_rates": [
          1.0,
          7.0,
          8.5
        ],
        "di_stability": [
          0.746,
          0.87,
          0.7
        ]
      }
    }
  },
  "compliance": {
    "use_case": {
      "title": "Credit Scoring & Financial Eligibility",
      "annex_ref": "Annex III, Point 5(b)",
      "is_high_risk": true,
      "description": "AI systems used to evaluate creditworthiness of natural persons or establish their credit score."
    },
    "is_high_risk": true,
    "pii_and_sensitive_signals": {
      "detected_pii_columns": [],
      "has_aadhaar_pattern": false,
      "has_minors": false,
      "minors_count": 0,
      "age_column": "Age"
    },
    "eu_ai_act": {
      "classification": "High-Risk AI System (Annex III)",
      "score": 81.8,
      "earned_points": 9.0,
      "max_points": 11.0,
      "checklist": [
        {
          "article": "Art. 9",
          "title": "Risk Management System",
          "type": "self_declared",
          "requirement": "Establish, implement, document and maintain a continuous risk management system.",
          "status": "yes",
          "evidence": "User declared operational risk management procedures."
        },
        {
          "article": "Art. 10",
          "title": "Data Governance & Bias Examination",
          "type": "auto_verified",
          "requirement": "Training, validation and testing data sets shall be relevant, representative, and examined for biases.",
          "status": "partial",
          "evidence": "Auto-verified: Disparate impact ratio or parity gaps in caution band. Requires data re-balancing."
        },
        {
          "article": "Art. 11",
          "title": "Technical Documentation",
          "type": "auto_verified",
          "requirement": "Draw up comprehensive technical documentation demonstrating regulatory conformity before deployment.",
          "status": "yes",
          "evidence": "Auto-verified: Automated AI Model Card and audit specifications compiled by AutoAudit-360 suite."
        },
        {
          "article": "Art. 12",
          "title": "Automatic Logging & Audit Trails",
          "type": "self_declared",
          "requirement": "High-risk AI systems shall technically allow for the automatic recording of events (logging).",
          "status": "yes",
          "evidence": "Audit logging verified."
        },
        {
          "article": "Art. 13",
          "title": "Transparency & Provision of Information",
          "type": "auto_verified",
          "requirement": "AI systems shall be accompanied by instructions for use and interpretable explanations.",
          "status": "partial",
          "evidence": "Auto-verified: 1 protected proxy feature identified in top 5 features."
        },
        {
          "article": "Art. 14",
          "title": "Human Oversight Measures",
          "type": "self_declared",
          "requirement": "Enable natural persons to oversee the system, prevent risks, or stop the system.",
          "status": "yes",
          "evidence": "Human-in-the-loop escalation pathway declared."
        },
        {
          "article": "Art. 15",
          "title": "Accuracy, Robustness & Cybersecurity",
          "type": "auto_verified",
          "requirement": "High-risk AI systems shall achieve appropriate levels of accuracy, robustness and cybersecurity.",
          "status": "yes",
          "evidence": "Auto-verified: Resilient against 10% label flips (<5% metric drop) and input perturbations."
        }
      ],
      "gaps": [
        "Conditional: Art. 10 (Data Governance & Bias Examination) is only partially fulfilled.",
        "Conditional: Art. 13 (Transparency & Provision of Information) is only partially fulfilled."
      ],
      "remediations": [
        "Upgrade Art. 10: Provide full evidence for 'Training, validation and testing data sets shall be relevant, representative, and examined for biases.'.",
        "Upgrade Art. 13: Provide full evidence for 'AI systems shall be accompanied by instructions for use and interpretable explanations.'."
      ]
    },
    "dpdp_act_2023": {
      "score": 90.0,
      "earned_points": 9.0,
      "max_points": 10.0,
      "checklist": [
        {
          "section": "Sec 5",
          "principle": "Notice Requirement",
          "type": "self_declared",
          "requirement": "Clear notice provided to Data Principal describing personal data collected and processing purpose.",
          "status": "yes",
          "evidence": "Notice protocol affirmed."
        },
        {
          "section": "Sec 6",
          "principle": "Consent Architecture",
          "type": "self_declared",
          "requirement": "Consent must be free, specific, informed, unconditional and unambiguous with clear affirmative action.",
          "status": "yes",
          "evidence": "Consent manager and withdrawal option verified."
        },
        {
          "section": "Sec 8(3)",
          "principle": "Data Accuracy & Completeness",
          "type": "auto_verified",
          "requirement": "Ensure data used to make decisions affecting Data Principals is accurate and complete.",
          "status": "yes",
          "evidence": "Auto-verified: Dataset is complete with 0.0% missing cells across all feature dimensions."
        },
        {
          "section": "Sec 8(5)",
          "principle": "Security Safeguards & Encryption",
          "type": "self_declared",
          "requirement": "Protect personal data in possession or custody under reasonable security safeguards.",
          "status": "partial",
          "evidence": "Reasonable security safeguards and access controls declared."
        },
        {
          "section": "Sec 8(6)",
          "principle": "Incident & Breach Notification",
          "type": "self_declared",
          "requirement": "Mandatory breach reporting to Data Protection Board of India and affected Principals.",
          "status": "yes",
          "evidence": "Incident response protocol within statutory timelines declared."
        },
        {
          "section": "Sec 9",
          "principle": "Processing of Children's Data",
          "type": "auto_verified",
          "requirement": "Obtain verifiable parental consent; strictly ban tracking, behavioral monitoring, or targeted ads directed at minors.",
          "status": "yes",
          "evidence": "Auto-verified: No records of minors (<18 years) detected in audit sample."
        },
        {
          "section": "Sec 10",
          "principle": "Significant Data Fiduciary Obligations",
          "type": "self_declared",
          "requirement": "Appoint India-resident DPO, conduct periodic Data Protection Impact Assessments (DPIA), and retain independent data auditor.",
          "status": "partial",
          "evidence": "DPO appointment or external data audit pending."
        },
        {
          "section": "Sec 11-13",
          "principle": "Data Principal Rights & Redressal",
          "type": "self_declared",
          "requirement": "Provide rights of access, correction, erasure, and easily accessible grievance redressal mechanism.",
          "status": "yes",
          "evidence": "Grievance redressal workflows declared."
        }
      ],
      "gaps": [
        "Conditional: Sec 8(5) (Security Safeguards & Encryption) is only partially fulfilled.",
        "Conditional: Sec 10 (Significant Data Fiduciary Obligations) is only partially fulfilled."
      ],
      "remediations": [
        "Upgrade Sec 8(5): Provide full evidence for 'Protect personal data in possession or custody under reasonable security safeguards.'.",
        "Upgrade Sec 10: Provide full evidence for 'Appoint India-resident DPO, conduct periodic Data Protection Impact Assessments (DPIA), and retain independent data auditor.'."
      ]
    }
  },
  "scores": {
    "overall_trust_score": 81.4,
    "rag_status": "green",
    "dimension_scores": {
      "Fairness": 37.5,
      "Explainability": 90.0,
      "Robustness": 88.9,
      "EU AI Act Readiness": 81.8,
      "DPDP Act 2023 Readiness": 90.0,
      "Documentation Completeness": 100.0
    }
  },
  "limitations": [
    "Audit findings reflect sample distribution characteristics and do not guarantee out-of-distribution parity.",
    "SHAP values measure empirical correlation in the trained estimator, not factual causality.",
    "Regulatory checklists represent readiness screening and do not substitute for formal legal certification.",
    "Note: Model was trained automatically using a standard baseline RandomForest pipeline as no external model file was supplied.",
    "Proxy risk: 1 protected or correlated features exert high predictive influence.",
    "Severe demographic disparities detected in positive classification rates."
  ]
};

export const COMPAS_AUDIT: FullAuditResult = {
  "meta": {
    "audit_id": "57037438",
    "timestamp": "2026-10-27 19:47:52 UTC",
    "model_name": "Model_57037438",
    "algorithm": "RandomForestClassifier (Auto-trained production baseline)",
    "is_default_trained": true,
    "framework": "scikit-learn",
    "random_seed": 42,
    "dataset_hash": "805bd8314af7bfab7cff8800c196beac7a98db62b343896102fb8db0bf97075b",
    "author": {
      "name": "VATSAL GADA",
      "prn": "124BTAI1005",
      "roll_no": "12",
      "class": "TY-AIDS",
      "institution": "SAKEC",
      "project": "AutoAudit-360: End-to-End Trustworthy AI Audit & Regulatory Compliance Suite"
    }
  },
  "data_summary": {
    "total_rows": 1200,
    "total_features": 9,
    "target_column": "Low_Risk_Outcome",
    "positive_label": "1",
    "positive_rate": 50.33,
    "sensitive_attributes": [
      "race",
      "sex"
    ],
    "missing_percentage": 0.0
  },
  "performance": {
    "accuracy": 1.0,
    "balanced_accuracy": 1.0,
    "precision": 1.0,
    "recall": 1.0,
    "f1_score": 1.0,
    "roc_auc": 1.0
  },
  "fairness": [
    {
      "attribute": "race",
      "privileged_group": "Other",
      "status": "fail",
      "severity": "high",
      "finding": "Disparate Impact (0.67) violates EEOC 80% rule (<0.7). Demographic Parity Difference (21.10%) exceeds 20% tolerance.",
      "metrics": {
        "disparate_impact_ratio": 0.673,
        "demographic_parity_difference": 0.211,
        "equal_opportunity_difference": 0.0,
        "equalized_odds_gap": 0.0,
        "worst_fpr_gap": 0.0
      },
      "subgroup_breakdown": {
        "African-American": {
          "size": 608,
          "selection_rate": 0.4342,
          "tpr": 1.0,
          "fpr": 0.0,
          "fnr": 0.0,
          "tnr": 1.0,
          "tp": 264,
          "fp": 0,
          "fn": 0,
          "tn": 344
        },
        "Caucasian": {
          "size": 397,
          "selection_rate": 0.5516,
          "tpr": 1.0,
          "fpr": 0.0,
          "fnr": 0.0,
          "tnr": 1.0,
          "tp": 219,
          "fp": 0,
          "fn": 0,
          "tn": 178
        },
        "Hispanic": {
          "size": 133,
          "selection_rate": 0.609,
          "tpr": 1.0,
          "fpr": 0.0,
          "fnr": 0.0,
          "tnr": 1.0,
          "tp": 81,
          "fp": 0,
          "fn": 0,
          "tn": 52
        },
        "Other": {
          "size": 62,
          "selection_rate": 0.6452,
          "tpr": 1.0,
          "fpr": 0.0,
          "fnr": 0.0,
          "tnr": 1.0,
          "tp": 40,
          "fp": 0,
          "fn": 0,
          "tn": 22
        }
      },
      "di_per_subgroup": {
        "African-American": 0.673,
        "Caucasian": 0.855,
        "Hispanic": 0.944
      },
      "small_group_warnings": [],
      "chart_data": {
        "labels": [
          "African-American",
          "Caucasian",
          "Hispanic",
          "Other"
        ],
        "selection_rates_pct": [
          43.42,
          55.16,
          60.9,
          64.52
        ],
        "eighty_percent_line_pct": 51.61,
        "privileged_rate_pct": 64.52
      }
    },
    {
      "attribute": "sex",
      "privileged_group": "Female",
      "status": "pass",
      "severity": "none",
      "finding": "All demographic parity and disparate impact checks passed within 80% rule thresholds.",
      "metrics": {
        "disparate_impact_ratio": 0.8997,
        "demographic_parity_difference": 0.055,
        "equal_opportunity_difference": 0.0,
        "equalized_odds_gap": 0.0,
        "worst_fpr_gap": 0.0
      },
      "subgroup_breakdown": {
        "Female": {
          "size": 204,
          "selection_rate": 0.549,
          "tpr": 1.0,
          "fpr": 0.0,
          "fnr": 0.0,
          "tnr": 1.0,
          "tp": 112,
          "fp": 0,
          "fn": 0,
          "tn": 92
        },
        "Male": {
          "size": 996,
          "selection_rate": 0.494,
          "tpr": 1.0,
          "fpr": 0.0,
          "fnr": 0.0,
          "tnr": 1.0,
          "tp": 492,
          "fp": 0,
          "fn": 0,
          "tn": 504
        }
      },
      "di_per_subgroup": {
        "Male": 0.8997
      },
      "small_group_warnings": [],
      "chart_data": {
        "labels": [
          "Female",
          "Male"
        ],
        "selection_rates_pct": [
          54.9,
          49.4
        ],
        "eighty_percent_line_pct": 43.92,
        "privileged_rate_pct": 54.9
      }
    }
  ],
  "explain": {
    "status": "warn",
    "severity": "medium",
    "explainer_type": "TreeExplainer",
    "shap_success": true,
    "finding": "Moderate Risk: 1 sensitive attribute or proxy variable detected in top 5 features. Protected features in top 5: cat__race_African-American. Causality Disclaimer: SHAP values quantify predictive attribution within the mathematical manifold, not causal mechanisms.",
    "disclaimer": "SHAP feature importances reflect marginal predictive contribution to the model's scoring manifold. They do NOT establish legal or real-world causality.",
    "top_features": [
      {
        "feature": "num__two_year_recid",
        "importance": 0.4145,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "num__priors_count",
        "importance": 0.0313,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__race_African-American",
        "importance": 0.0156,
        "is_sensitive": true,
        "is_proxy": false
      },
      {
        "feature": "num__age",
        "importance": 0.0145,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__age_cat_Greater than 45",
        "importance": 0.0098,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "num__juv_fel_count",
        "importance": 0.005,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__age_cat_25 - 45",
        "importance": 0.0041,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "num__juv_misd_count",
        "importance": 0.0033,
        "is_sensitive": false,
        "is_proxy": false
      },
      {
        "feature": "cat__race_Hispanic",
        "importance": 0.0029,
        "is_sensitive": true,
        "is_proxy": false
      },
      {
        "feature": "cat__sex_Female",
        "importance": 0.0027,
        "is_sensitive": true,
        "is_proxy": false
      }
    ],
    "sensitive_in_top_5": [
      "cat__race_African-American"
    ],
    "proxies_in_top_5": [],
    "flagged_count": 1,
    "chart_data": {
      "labels": [
        "num__two_year_recid",
        "num__priors_count",
        "cat__race_African-American",
        "num__age",
        "cat__age_cat_Greater than 45",
        "num__juv_fel_count",
        "cat__age_cat_25 - 45",
        "num__juv_misd_count",
        "cat__race_Hispanic",
        "cat__sex_Female"
      ],
      "values": [
        0.4145,
        0.0313,
        0.0156,
        0.0145,
        0.0098,
        0.005,
        0.0041,
        0.0033,
        0.0029,
        0.0027
      ]
    }
  },
  "robustness": {
    "status": "pass",
    "severity": "none",
    "finding": "Model exhibits high robustness: metric drop at 10% label flips is 0.4% (<=5% pass threshold). Inferences remain steady under perturbation. Fairness stability preserved: Disparate Impact remains robust under feature jitter (delta 0.07).",
    "baseline_metrics": {
      "accuracy": 1.0,
      "f1": 1.0,
      "roc_auc": 1.0
    },
    "metric_drop_10pct": 0.0041,
    "prediction_flip_rate_5pct": 0.0,
    "fairness_stability_delta": 0.0703,
    "label_flip_tests": [
      {
        "flip_rate_pct": 5,
        "accuracy": 0.9958,
        "f1": 0.9959,
        "roc_auc": 1.0,
        "accuracy_drop": 0.0042,
        "f1_drop": 0.0041,
        "roc_auc_drop": 0.0,
        "relative_metric_drop": 0.0041
      },
      {
        "flip_rate_pct": 10,
        "accuracy": 0.9958,
        "f1": 0.9959,
        "roc_auc": 1.0,
        "accuracy_drop": 0.0042,
        "f1_drop": 0.0041,
        "roc_auc_drop": 0.0,
        "relative_metric_drop": 0.0041
      },
      {
        "flip_rate_pct": 20,
        "accuracy": 0.9708,
        "f1": 0.9717,
        "roc_auc": 0.9992,
        "accuracy_drop": 0.0292,
        "f1_drop": 0.0283,
        "roc_auc_drop": 0.0008,
        "relative_metric_drop": 0.0287
      }
    ],
    "perturbation_tests": [
      {
        "noise_level_pct": 1,
        "prediction_flip_rate": 0.0,
        "accuracy": 1.0,
        "accuracy_drop": 0.0,
        "disparate_impact": 0.6908,
        "di_delta": 0.0256
      },
      {
        "noise_level_pct": 5,
        "prediction_flip_rate": 0.0,
        "accuracy": 1.0,
        "accuracy_drop": 0.0,
        "disparate_impact": 0.6462,
        "di_delta": 0.0703
      },
      {
        "noise_level_pct": 10,
        "prediction_flip_rate": 0.0,
        "accuracy": 1.0,
        "accuracy_drop": 0.0,
        "disparate_impact": 0.7403,
        "di_delta": 0.0238
      }
    ],
    "chart_data": {
      "label_flips": {
        "x_labels": [
          "0%",
          "5%",
          "10%",
          "20%"
        ],
        "accuracy": [
          1.0,
          0.9958,
          0.9958,
          0.9708
        ],
        "f1": [
          1.0,
          0.9959,
          0.9959,
          0.9717
        ],
        "roc_auc": [
          1.0,
          1.0,
          1.0,
          0.9992
        ]
      },
      "perturbation": {
        "x_labels": [
          "1% Noise",
          "5% Noise",
          "10% Noise"
        ],
        "flip_rates": [
          0.0,
          0.0,
          0.0
        ],
        "di_stability": [
          0.691,
          0.646,
          0.74
        ]
      }
    }
  },
  "compliance": {
    "use_case": {
      "title": "Law Enforcement & Recidivism Assessment",
      "annex_ref": "Annex III, Point 6",
      "is_high_risk": true,
      "description": "AI systems used by authorities to assess the risk of a natural person offending or reoffending."
    },
    "is_high_risk": true,
    "pii_and_sensitive_signals": {
      "detected_pii_columns": [],
      "has_aadhaar_pattern": false,
      "has_minors": false,
      "minors_count": 0,
      "age_column": "age"
    },
    "eu_ai_act": {
      "classification": "High-Risk AI System (Annex III)",
      "score": 72.7,
      "earned_points": 8.0,
      "max_points": 11.0,
      "checklist": [
        {
          "article": "Art. 9",
          "title": "Risk Management System",
          "type": "self_declared",
          "requirement": "Establish, implement, document and maintain a continuous risk management system.",
          "status": "yes",
          "evidence": "User declared operational risk management procedures."
        },
        {
          "article": "Art. 10",
          "title": "Data Governance & Bias Examination",
          "type": "auto_verified",
          "requirement": "Training, validation and testing data sets shall be relevant, representative, and examined for biases.",
          "status": "no",
          "evidence": "Auto-verified: Demographic disparity or 80% rule failure detected in model inferences."
        },
        {
          "article": "Art. 11",
          "title": "Technical Documentation",
          "type": "auto_verified",
          "requirement": "Draw up comprehensive technical documentation demonstrating regulatory conformity before deployment.",
          "status": "yes",
          "evidence": "Auto-verified: Automated AI Model Card and audit specifications compiled by AutoAudit-360 suite."
        },
        {
          "article": "Art. 12",
          "title": "Automatic Logging & Audit Trails",
          "type": "self_declared",
          "requirement": "High-risk AI systems shall technically allow for the automatic recording of events (logging).",
          "status": "yes",
          "evidence": "Audit logging verified."
        },
        {
          "article": "Art. 13",
          "title": "Transparency & Provision of Information",
          "type": "auto_verified",
          "requirement": "AI systems shall be accompanied by instructions for use and interpretable explanations.",
          "status": "partial",
          "evidence": "Auto-verified: 1 protected proxy feature identified in top 5 features."
        },
        {
          "article": "Art. 14",
          "title": "Human Oversight Measures",
          "type": "self_declared",
          "requirement": "Enable natural persons to oversee the system, prevent risks, or stop the system.",
          "status": "yes",
          "evidence": "Human-in-the-loop escalation pathway declared."
        },
        {
          "article": "Art. 15",
          "title": "Accuracy, Robustness & Cybersecurity",
          "type": "auto_verified",
          "requirement": "High-risk AI systems shall achieve appropriate levels of accuracy, robustness and cybersecurity.",
          "status": "yes",
          "evidence": "Auto-verified: Resilient against 10% label flips (<5% metric drop) and input perturbations."
        }
      ],
      "gaps": [
        "Deficiency: Art. 10 (Data Governance & Bias Examination) failed or unaddressed.",
        "Conditional: Art. 13 (Transparency & Provision of Information) is only partially fulfilled."
      ],
      "remediations": [
        "Immediate remediation required for Art. 10: Training, validation and testing data sets shall be relevant, representative, and examined for biases.",
        "Upgrade Art. 13: Provide full evidence for 'AI systems shall be accompanied by instructions for use and interpretable explanations.'."
      ]
    },
    "dpdp_act_2023": {
      "score": 90.0,
      "earned_points": 9.0,
      "max_points": 10.0,
      "checklist": [
        {
          "section": "Sec 5",
          "principle": "Notice Requirement",
          "type": "self_declared",
          "requirement": "Clear notice provided to Data Principal describing personal data collected and processing purpose.",
          "status": "yes",
          "evidence": "Notice protocol affirmed."
        },
        {
          "section": "Sec 6",
          "principle": "Consent Architecture",
          "type": "self_declared",
          "requirement": "Consent must be free, specific, informed, unconditional and unambiguous with clear affirmative action.",
          "status": "yes",
          "evidence": "Consent manager and withdrawal option verified."
        },
        {
          "section": "Sec 8(3)",
          "principle": "Data Accuracy & Completeness",
          "type": "auto_verified",
          "requirement": "Ensure data used to make decisions affecting Data Principals is accurate and complete.",
          "status": "yes",
          "evidence": "Auto-verified: Dataset is complete with 0.0% missing cells across all feature dimensions."
        },
        {
          "section": "Sec 8(5)",
          "principle": "Security Safeguards & Encryption",
          "type": "self_declared",
          "requirement": "Protect personal data in possession or custody under reasonable security safeguards.",
          "status": "partial",
          "evidence": "Reasonable security safeguards and access controls declared."
        },
        {
          "section": "Sec 8(6)",
          "principle": "Incident & Breach Notification",
          "type": "self_declared",
          "requirement": "Mandatory breach reporting to Data Protection Board of India and affected Principals.",
          "status": "yes",
          "evidence": "Incident response protocol within statutory timelines declared."
        },
        {
          "section": "Sec 9",
          "principle": "Processing of Children's Data",
          "type": "auto_verified",
          "requirement": "Obtain verifiable parental consent; strictly ban tracking, behavioral monitoring, or targeted ads directed at minors.",
          "status": "yes",
          "evidence": "Auto-verified: No records of minors (<18 years) detected in audit sample."
        },
        {
          "section": "Sec 10",
          "principle": "Significant Data Fiduciary Obligations",
          "type": "self_declared",
          "requirement": "Appoint India-resident DPO, conduct periodic Data Protection Impact Assessments (DPIA), and retain independent data auditor.",
          "status": "partial",
          "evidence": "DPO appointment or external data audit pending."
        },
        {
          "section": "Sec 11-13",
          "principle": "Data Principal Rights & Redressal",
          "type": "self_declared",
          "requirement": "Provide rights of access, correction, erasure, and easily accessible grievance redressal mechanism.",
          "status": "yes",
          "evidence": "Grievance redressal workflows declared."
        }
      ],
      "gaps": [
        "Conditional: Sec 8(5) (Security Safeguards & Encryption) is only partially fulfilled.",
        "Conditional: Sec 10 (Significant Data Fiduciary Obligations) is only partially fulfilled."
      ],
      "remediations": [
        "Upgrade Sec 8(5): Provide full evidence for 'Protect personal data in possession or custody under reasonable security safeguards.'.",
        "Upgrade Sec 10: Provide full evidence for 'Appoint India-resident DPO, conduct periodic Data Protection Impact Assessments (DPIA), and retain independent data auditor.'."
      ]
    }
  },
  "scores": {
    "overall_trust_score": 84.9,
    "rag_status": "green",
    "dimension_scores": {
      "Fairness": 57.4,
      "Explainability": 90.0,
      "Robustness": 99.4,
      "EU AI Act Readiness": 72.7,
      "DPDP Act 2023 Readiness": 90.0,
      "Documentation Completeness": 100.0
    }
  },
  "limitations": [
    "Audit findings reflect sample distribution characteristics and do not guarantee out-of-distribution parity.",
    "SHAP values measure empirical correlation in the trained estimator, not factual causality.",
    "Regulatory checklists represent readiness screening and do not substitute for formal legal certification.",
    "Note: Model was trained automatically using a standard baseline RandomForest pipeline as no external model file was supplied.",
    "Proxy risk: 1 protected or correlated features exert high predictive influence.",
    "Severe demographic disparities detected in positive classification rates."
  ]
};
