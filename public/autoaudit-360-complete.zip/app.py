"""
AutoAudit-360: Flask REST JSON API
Exposes trustworthy AI audits, model card downloads, dataset uploads, and demo endpoints.
"""

import os
import uuid
import json
from flask import Flask, request, jsonify, send_file, Response
from werkzeug.utils import secure_filename
import pandas as pd
import joblib

from config import UPLOAD_MAX_BYTES
from audit_model import run_audit
from auditors.modelcard import generate_model_card_html
from demo_data.loaders import get_german_credit_data, get_compas_data

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["MAX_CONTENT_LENGTH"] = UPLOAD_MAX_BYTES

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_STORE_DIR = os.path.join(BASE_DIR, "data_store")
AUDIT_STORE_DIR = os.path.join(BASE_DIR, "outputs")
os.makedirs(DATA_STORE_DIR, exist_ok=True)
os.makedirs(AUDIT_STORE_DIR, exist_ok=True)

# In-memory session cache for datasets and audits
DATASETS_CACHE = {}
AUDITS_CACHE = {}

def get_df_summary(df: pd.DataFrame) -> dict:
    dtypes = {}
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            dtypes[col] = "numeric"
        else:
            dtypes[col] = "categorical"
    preview = df.head(5).to_dict(orient="records")
    return {
        "columns": list(df.columns),
        "dtypes": dtypes,
        "row_count": len(df),
        "preview": preview
    }

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "healthy",
        "service": "AutoAudit-360 Trustworthy AI Engine",
        "version": "1.0.0",
        "author": {
            "name": "Vatsal Gada",
            "prn": "124BTAI1005",
            "roll_no": 12,
            "institution": "SAKEC (TY-AIDS)"
        }
    })

@app.route("/api/upload", methods=["POST"])
def upload():
    """Upload dataset CSV and optional pickled scikit-learn model."""
    if "file" not in request.files:
        return jsonify({"error": "No CSV data file provided in 'file' field."}), 400
        
    csv_file = request.files["file"]
    if not csv_file.filename.endswith(".csv"):
        return jsonify({"error": "Only CSV files are accepted for dataset."}), 400

    dataset_id = str(uuid.uuid4())[:10]
    csv_path = os.path.join(DATA_STORE_DIR, f"{dataset_id}.csv")
    csv_file.save(csv_path)

    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        return jsonify({"error": f"Failed to parse CSV file: {str(e)}"}), 400

    # Optional model upload
    model_path = None
    if "model" in request.files:
        m_file = request.files["model"]
        if m_file.filename:
            m_name = secure_filename(m_file.filename)
            if not (m_name.endswith(".joblib") or m_name.endswith(".pkl")):
                return jsonify({"error": "Model file must be .joblib or .pkl."}), 400
            model_path = os.path.join(DATA_STORE_DIR, f"{dataset_id}_{m_name}")
            m_file.save(model_path)

    DATASETS_CACHE[dataset_id] = {
        "csv_path": csv_path,
        "model_path": model_path,
        "df": df
    }

    summary = get_df_summary(df)
    return jsonify({
        "dataset_id": dataset_id,
        "has_custom_model": model_path is not None,
        "columns": summary["columns"],
        "dtypes": summary["dtypes"],
        "row_count": summary["row_count"],
        "preview": summary["preview"]
    })

@app.route("/api/demo/<name>", methods=["GET"])
def demo_data(name: str):
    """One-click demo dataset loaders: german_credit or compas."""
    dataset_id = f"demo_{name}"
    
    if name == "german_credit":
        df = get_german_credit_data()
        default_target = "Creditability"
        default_positive = 1
        default_sensitive = ["Sex", "Age"]
        default_use_case = "credit_scoring"
    elif name == "compas":
        df = get_compas_data()
        default_target = "Low_Risk_Outcome"
        default_positive = 1
        default_sensitive = ["race", "sex"]
        default_use_case = "law_enforcement_recidivism"
    else:
        return jsonify({"error": f"Unknown demo '{name}'. Choose 'german_credit' or 'compas'."}), 404

    csv_path = os.path.join(DATA_STORE_DIR, f"{dataset_id}.csv")
    df.to_csv(csv_path, index=False)

    DATASETS_CACHE[dataset_id] = {
        "csv_path": csv_path,
        "model_path": None,
        "df": df
    }

    summary = get_df_summary(df)
    return jsonify({
        "dataset_id": dataset_id,
        "demo_name": name,
        "default_target": default_target,
        "default_positive": default_positive,
        "default_sensitive": default_sensitive,
        "default_use_case": default_use_case,
        "columns": summary["columns"],
        "dtypes": summary["dtypes"],
        "row_count": summary["row_count"],
        "preview": summary["preview"]
    })

@app.route("/api/audit", methods=["POST"])
def audit():
    """Execute full battery of audits."""
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "Invalid JSON body"}), 400

    dataset_id = data.get("dataset_id")
    target = data.get("target")
    sensitive = data.get("sensitive", [])
    positive_label = data.get("positive_label", 1)
    use_case = data.get("use_case", "credit_scoring")
    questionnaire = data.get("questionnaire", {})
    privileged_groups = data.get("privileged_groups", {})

    if not dataset_id or dataset_id not in DATASETS_CACHE:
        # Check if saved on disk
        csv_disk = os.path.join(DATA_STORE_DIR, f"{dataset_id}.csv")
        if os.path.exists(csv_disk):
            df = pd.read_csv(csv_disk)
            DATASETS_CACHE[dataset_id] = {"csv_path": csv_disk, "model_path": None, "df": df}
        else:
            return jsonify({"error": "Dataset ID not found. Upload data first or use a demo."}), 404

    cached = DATASETS_CACHE[dataset_id]
    df = cached["df"]
    
    if not target or target not in df.columns:
        return jsonify({"error": f"Target column '{target}' not present in dataset."}), 400

    if not sensitive or not isinstance(sensitive, list):
        return jsonify({"error": "At least one sensitive attribute must be specified in 'sensitive' list."}), 400

    # Typecast positive_label
    try:
        positive_label = int(positive_label)
    except (ValueError, TypeError):
        pass

    # Model loading
    custom_model = None
    if cached.get("model_path") and os.path.exists(cached["model_path"]):
        try:
            custom_model = joblib.load(cached["model_path"])
        except Exception as e:
            return jsonify({"error": f"Failed to unpickle model: {str(e)}"}), 400

    audit_id = str(uuid.uuid4())[:8]

    try:
        audit_result = run_audit(
            df=df,
            target_col=target,
            sensitive_cols=sensitive,
            model=custom_model,
            positive_label=positive_label,
            use_case=use_case,
            questionnaire=questionnaire,
            privileged_groups=privileged_groups,
            audit_id=audit_id
        )
    except Exception as e:
        return jsonify({"error": f"Audit execution failure: {str(e)}"}), 500

    AUDITS_CACHE[audit_id] = audit_result
    
    # Save to disk outputs for persistence
    json_path = os.path.join(AUDIT_STORE_DIR, f"{audit_id}.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(audit_result, f, indent=2)

    html_path = os.path.join(AUDIT_STORE_DIR, f"{audit_id}.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(generate_model_card_html(audit_result))

    return jsonify(audit_result)

@app.route("/api/modelcard/<audit_id>.<ext>", methods=["GET"])
def get_modelcard(audit_id: str, ext: str):
    """Download compiled Model Card in HTML or JSON format."""
    ext = ext.lower()
    if ext not in ["html", "json"]:
        return jsonify({"error": "Extension must be 'html' or 'json'."}), 400

    file_path = os.path.join(AUDIT_STORE_DIR, f"{audit_id}.{ext}")
    
    # If not on disk, check cache and generate
    if not os.path.exists(file_path):
        if audit_id in AUDITS_CACHE:
            audit_result = AUDITS_CACHE[audit_id]
            if ext == "html":
                content = generate_model_card_html(audit_result)
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)
            else:
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(audit_result, f, indent=2)
        else:
            return jsonify({"error": f"Model Card with audit ID '{audit_id}' not found."}), 404

    if ext == "html":
        return send_file(file_path, mimetype="text/html", as_attachment=True, download_name=f"modelcard_{audit_id}.html")
    else:
        return send_file(file_path, mimetype="application/json", as_attachment=True, download_name=f"modelcard_{audit_id}.json")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
