"""
AutoAudit-360 Configuration & Scoring Specification
Domain: AI Governance, Policy & Risk Management
Student: Vatsal Gada | PRN: 124BTAI1005 | Roll No: 12 | TY-AIDS (SAKEC)
"""

# Thresholds for Fair Lending & Employment Guidelines (e.g. EEOC 80% Rule)
THRESHOLDS = {
    # Disparate Impact (Four-Fifths Rule)
    "disparate_impact": {
        "pass": 0.80,
        "warn": 0.70,  # [0.70, 0.80) is warning
        "fail": 0.70,  # < 0.70 is fail
    },
    # Demographic Parity Difference (DPD) & Equal Opportunity Difference (EOD)
    "parity_gap": {
        "pass": 0.10,
        "warn": 0.20,  # (0.10, 0.20] is warning
        "fail": 0.20,  # > 0.20 is fail
    },
    # Robustness Metric Drop at 10% synthetic label flips
    "robustness_metric_drop_10pct": {
        "pass": 0.05,  # <= 5% drop is pass
        "warn": 0.12,  # 5% to 12% is warn, > 12% is fail
    },
    # Perturbation Flip Rate at 5% noise
    "perturbation_flip_rate_5pct": {
        "pass": 0.08,
        "warn": 0.18,
    },
    # Minimum sample size per demographic subgroup to prevent statistical noise
    "min_subgroup_sample_size": 30,
    # Correlation threshold to consider a non-sensitive feature as a "proxy" attribute
    "proxy_correlation_threshold": 0.40,
    # Max samples for SHAP background to stay within execution budget (< 60s)
    "shap_max_background_samples": 80,
    "shap_max_eval_samples": 200,
}

# RAG Status Thresholds
RAG_THRESHOLDS = {
    "green": 75.0,  # Score >= 75: Green (Certified / Pass)
    "amber": 50.0,  # Score 50 - 74.9: Amber (Conditional / Review)
    "red": 0.0,     # Score < 50: Red (High Risk / Fail)
}

# Weights for Regulatory Compliance Checklist
COMPLIANCE_WEIGHTS = {
    "auto_verified": 2.0,
    "self_declared": 1.0,
    "partial_multiplier": 0.5,
    "yes_multiplier": 1.0,
    "no_multiplier": 0.0,
}

# Radar Chart Axis Weights for Overall Trust Score (Arithmetic mean)
RADAR_AXES = [
    "Fairness",
    "Explainability",
    "Robustness",
    "EU AI Act Readiness",
    "DPDP Act 2023 Readiness",
    "Documentation Completeness"
]

RANDOM_SEED = 42
UPLOAD_MAX_BYTES = 20 * 1024 * 1024  # 20 MB limit
